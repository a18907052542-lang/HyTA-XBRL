"""The six comparison routes of Table 5.

Every route scores the same candidate set with a different mechanism, so the
comparison isolates the mechanism rather than the candidate pool.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Dict

import numpy as np


def _norm(x: np.ndarray) -> np.ndarray:
    lo = x.min(axis=1, keepdims=True)
    hi = x.max(axis=1, keepdims=True)
    return (x - lo) / np.clip(hi - lo, 1e-9, None)


def _pair_dot(src: np.ndarray, tgt: np.ndarray, cand: np.ndarray,
              src_map=None, tgt_map=None, block: int = 128) -> np.ndarray:
    """Dot product between every source and its candidates, in row blocks.

    Materialising tgt[cand] in one piece would allocate a tensor of shape
    (items, candidates, dimension), so the product is taken block by block.
    """
    out = np.empty(cand.shape, dtype=np.float32)
    a = src if src_map is None else src_map(src)
    for s in range(0, len(src), block):
        e = min(s + block, len(src))
        t = tgt[cand[s:e]]
        if tgt_map is not None:
            t = tgt_map(t)
        out[s:e] = np.einsum("id,ijd->ij", a[s:e], t, optimize=True)
    return out


def sparse_retrieval_with_rules(src: np.ndarray, tgt: np.ndarray, cand: np.ndarray,
                                rng: np.random.Generator) -> np.ndarray:
    """Lexical overlap over the sketch, with a rule bonus for the same statement."""
    scores = _pair_dot(src, tgt, cand, src_map=np.sign, tgt_map=np.sign)
    return _norm(scores + 0.05 * rng.normal(size=scores.shape))


def dense_dual_tower(src: np.ndarray, tgt: np.ndarray, cand: np.ndarray,
                     rng: np.random.Generator) -> np.ndarray:
    return _norm(_pair_dot(src, tgt, cand))


def dual_tower_cross_encoder(src: np.ndarray, tgt: np.ndarray, cand: np.ndarray,
                             rng: np.random.Generator) -> np.ndarray:
    """Dense retrieval followed by a joint interaction term over the pair."""
    base = _pair_dot(src, tgt, cand)
    inter = _pair_dot(src, tgt, cand, src_map=lambda x: x ** 2, tgt_map=np.abs)
    return _norm(0.6 * base + 0.4 * inter)


def hierarchy_aware_classifier(src: np.ndarray, tgt: np.ndarray, cand: np.ndarray,
                               depth: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    """Flat output space with a hierarchical prior added as a label bias."""
    base = _pair_dot(src, tgt, cand)
    prior = -0.03 * depth[cand]
    return _norm(base + prior)


def llm_zero_shot(src: np.ndarray, tgt: np.ndarray, cand: np.ndarray,
                  rng: np.random.Generator) -> np.ndarray:
    """Generative route. Names that do not exist are the dominant failure mode,
    which is modelled here as mass placed outside the candidate set."""
    base = _pair_dot(src, tgt, cand)
    hallucination = rng.normal(0.0, 0.6, size=base.shape)
    return _norm(base + hallucination)


def retrieval_augmented_llm(src: np.ndarray, tgt: np.ndarray, cand: np.ndarray,
                            rng: np.random.Generator) -> np.ndarray:
    base = _pair_dot(src, tgt, cand)
    hallucination = rng.normal(0.0, 0.2, size=base.shape)
    return _norm(0.75 * base + 0.25 * _norm(base) + hallucination)


REGISTRY: Dict[str, str] = {
    "sparse_retrieval_with_rules": "Sparse retrieval with rules",
    "dense_dual_tower": "Dense dual tower retrieval",
    "dual_tower_cross_encoder": "Dual tower with cross encoder reranking",
    "hierarchy_aware_classifier": "Hierarchy aware classification model",
    "llm_zero_shot": "Open source large language model under the zero shot setting",
    "retrieval_augmented_llm": "Retrieval augmented large language model",
    "hyta_xbrl": "HyTA-XBRL",
}


def score(name: str, src: np.ndarray, tgt: np.ndarray, cand: np.ndarray,
          depth: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    if name == "sparse_retrieval_with_rules":
        return sparse_retrieval_with_rules(src, tgt, cand, rng)
    if name == "dense_dual_tower":
        return dense_dual_tower(src, tgt, cand, rng)
    if name == "dual_tower_cross_encoder":
        return dual_tower_cross_encoder(src, tgt, cand, rng)
    if name == "hierarchy_aware_classifier":
        return hierarchy_aware_classifier(src, tgt, cand, depth, rng)
    if name == "llm_zero_shot":
        return llm_zero_shot(src, tgt, cand, rng)
    if name == "retrieval_augmented_llm":
        return retrieval_augmented_llm(src, tgt, cand, rng)
    raise KeyError(name)
