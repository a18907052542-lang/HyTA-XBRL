"""CalcJoint: statement level joint assignment driven by calculation constraints.

Equation (12)  max sum_e ( sum_t s(e,t) z_et + eta z_e_perp )
Equation (13)  | sum_children ( w_pt v(e) z_et + w_pe v(e) z_e_perp ) - v(p) | <= kappa |v(p)|
Equation (14)  differentiable soft assignment with entropy and Lagrange terms
Equation (15)  L = L_rank + L_mig + xi * sum_p g_p

Four groups of constraints, as in Table 2 of the manuscript:
    row          each element takes at most one target or the abstention column
    exclusivity  two elements of one calculation sibling group may not share a target
    summation    equation (13)
    attribute    identical period type, compatible balance, identical unit
"""
from __future__ import annotations
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.sparse import coo_matrix


@dataclass
class ReportProblem:
    element_ids: List[str]
    candidate_ids: np.ndarray          # (n_elements, n_candidates) indices into the target space
    scores: np.ndarray                 # (n_elements, n_candidates)
    values: np.ndarray                 # (n_elements,) reported values
    filer_weight: np.ndarray           # (n_elements,) w_pe on the arc of the filer
    sibling_group: np.ndarray          # (n_elements,) calculation sibling group id
    parent_value: Dict[int, float]     # group id -> v(p)
    target_weight: np.ndarray          # (n_elements, n_candidates) w_pt
    attribute_ok: np.ndarray           # (n_elements, n_candidates) bool
    eta: float


@dataclass
class ReportSolution:
    chosen: np.ndarray                 # index into candidates, or -1 for abstention
    status: str                        # optimal | greedy_repair
    seconds: float
    violations: Dict[str, int] = field(default_factory=dict)


# --------------------------------------------------------------- inference
def solve_report(problem: ReportProblem, kappa: float, time_limit: float,
                 strong_coupling_block_size: int, greedy_alternatives: int = 2) -> ReportSolution:
    """Exact integer programme, with a greedy repair on timeout."""
    n, m = problem.scores.shape
    t0 = time.perf_counter()
    n_vars = n * (m + 1)                      # m targets plus one abstention column

    # objective, equation (12); milp minimises, so the sign is flipped
    c = np.zeros(n_vars)
    for i in range(n):
        c[i * (m + 1):i * (m + 1) + m] = -problem.scores[i]
        c[i * (m + 1) + m] = -problem.eta

    rows, cols, data, lb, ub = [], [], [], [], []
    r = 0
    # row constraint: exactly one column per element
    for i in range(n):
        for j in range(m + 1):
            rows.append(r); cols.append(i * (m + 1) + j); data.append(1.0)
        lb.append(1.0); ub.append(1.0); r += 1
    # attribute compatibility: incompatible columns are forced to zero
    for i in range(n):
        for j in range(m):
            if not problem.attribute_ok[i, j]:
                rows.append(r); cols.append(i * (m + 1) + j); data.append(1.0)
                lb.append(0.0); ub.append(0.0); r += 1
    # exclusivity inside a calculation sibling group
    for g in np.unique(problem.sibling_group):
        members = np.where(problem.sibling_group == g)[0]
        if len(members) < 2:
            continue
        shared: Dict[int, List[int]] = {}
        for i in members:
            for j in range(m):
                shared.setdefault(int(problem.candidate_ids[i, j]), []).append(i * (m + 1) + j)
        for _, var_ids in shared.items():
            if len(var_ids) < 2:
                continue
            for v in var_ids:
                rows.append(r); cols.append(v); data.append(1.0)
            lb.append(0.0); ub.append(1.0); r += 1
    # summation consistency, equation (13), written as two one sided rows
    coupled = False
    for g, v_p in problem.parent_value.items():
        members = np.where(problem.sibling_group == g)[0]
        if len(members) == 0:
            continue
        if len(members) >= strong_coupling_block_size:
            coupled = True
        tol = kappa * abs(v_p)
        for i in members:
            for j in range(m):
                rows.append(r); cols.append(i * (m + 1) + j)
                data.append(problem.target_weight[i, j] * problem.values[i])
            rows.append(r); cols.append(i * (m + 1) + m)
            data.append(problem.filer_weight[i] * problem.values[i])
        lb.append(v_p - tol); ub.append(v_p + tol); r += 1

    A = coo_matrix((data, (rows, cols)), shape=(r, n_vars))
    constraints = LinearConstraint(A, np.array(lb), np.array(ub))
    integrality = np.ones(n_vars)
    bounds = Bounds(0, 1)
    tight = time_limit < 0.01                      # the strongly coupled path
    res = milp(c=c, constraints=constraints, integrality=integrality, bounds=bounds,
               options={"time_limit": max(time_limit, 1e-4), "presolve": not tight,
                        "mip_rel_gap": 0.0})
    seconds = time.perf_counter() - t0

    if res.success and res.x is not None:
        z = res.x.reshape(n, m + 1)
        chosen = np.argmax(z, axis=1)
        chosen = np.where(chosen == m, -1, chosen)
        return ReportSolution(chosen, "optimal", seconds, violations={})

    chosen, viol = greedy_repair(problem, greedy_alternatives)
    return ReportSolution(chosen, "greedy_repair", time.perf_counter() - t0, viol)


def greedy_repair(problem: ReportProblem, alternatives: int = 2) -> Tuple[np.ndarray, Dict[str, int]]:
    """Fallback used when the solver cannot prove feasibility inside the limit.

    Takes the best scoring column for every element, then repairs the two hard
    accounting errors in order: duplicate measurement first, sign reversal
    second. Whatever survives the repair is reported as a residual violation,
    which is the source of the residual duplicate and sign rates in Table 6.
    """
    n, m = problem.scores.shape
    chosen = np.argmax(problem.scores, axis=1)
    for i in range(n):
        if not problem.attribute_ok[i, chosen[i]]:
            ok = np.where(problem.attribute_ok[i])[0]
            chosen[i] = ok[np.argmax(problem.scores[i, ok])] if len(ok) else -1

    dup, sgn = 0, 0
    for g in np.unique(problem.sibling_group):
        members = np.where(problem.sibling_group == g)[0]
        if len(members) < 2:
            continue
        seen: Dict[int, int] = {}
        for i in members:
            if chosen[i] < 0:
                continue
            tid = int(problem.candidate_ids[i, chosen[i]])
            if tid not in seen:
                seen[tid] = i
                continue
            # duplicate measurement inside one calculation sibling group
            alt = np.argsort(-problem.scores[i])
            moved = False
            for j in alt[1:1 + alternatives]:
                j = int(j)
                if int(problem.candidate_ids[i, j]) in seen or not problem.attribute_ok[i, j]:
                    continue
                before = float(np.sign(problem.target_weight[i, chosen[i]]))
                chosen[i] = j
                seen[int(problem.candidate_ids[i, j])] = i
                moved = True
                if float(np.sign(problem.target_weight[i, j])) != before:
                    sgn += 1                       # the move reversed the sign it enters with
                break
            if not moved:
                chosen[i] = -1
                dup += 1
    return chosen, {"duplicate_measurement": dup, "sign_reversal": sgn}


# ---------------------------------------------------------------- training
def soft_assignment(scores: np.ndarray, mu: float, multipliers: np.ndarray,
                    violation_jacobian: np.ndarray) -> np.ndarray:
    """Equation (14): entropy regularised row normalised soft assignment."""
    logits = (scores - violation_jacobian * multipliers[:, None]) / max(mu, 1e-6)
    logits -= logits.max(axis=1, keepdims=True)
    z = np.exp(logits)
    return z / np.clip(z.sum(axis=1, keepdims=True), 1e-12, None)


def summation_violation(z: np.ndarray, values: np.ndarray, target_weight: np.ndarray,
                        sibling_group: np.ndarray, parent_value: Dict[int, float]) -> np.ndarray:
    """g_p in equations (14) and (15)."""
    out = []
    for g, v_p in parent_value.items():
        members = np.where(sibling_group == g)[0]
        total = float((z[members] * target_weight[members] * values[members, None]).sum())
        out.append(abs(total - v_p) / max(abs(v_p), 1e-9))
    return np.asarray(out, dtype=float)


def lagrangian_relaxation(scores: np.ndarray, values: np.ndarray, target_weight: np.ndarray,
                          sibling_group: np.ndarray, parent_value: Dict[int, float],
                          mu: float, step: float, iterations: int) -> Tuple[np.ndarray, float]:
    """Subgradient updates of the multipliers of equation (14)."""
    groups = list(parent_value.keys())
    zeta = np.zeros(len(scores))
    z = soft_assignment(scores, mu, zeta, np.zeros_like(scores))
    total = 0.0
    for _ in range(iterations):
        g = summation_violation(z, values, target_weight, sibling_group, parent_value)
        total = float(g.sum())
        jac = np.zeros_like(scores)
        for k, grp in enumerate(groups):
            members = np.where(sibling_group == grp)[0]
            jac[members] = g[k] * np.sign(target_weight[members] * values[members, None])
        zeta = np.clip(zeta + step * jac.mean(axis=1), 0.0, 50.0)
        z = soft_assignment(scores, mu, zeta, jac)
    return z, total


def total_loss(l_rank: float, l_mig: float, violations: np.ndarray, xi: float) -> float:
    """Equation (15)."""
    return float(l_rank + l_mig + xi * np.sum(violations))
