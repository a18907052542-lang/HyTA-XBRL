"""Lorentz model of hyperbolic space.

Equation (5)  d(u, v) = arcosh( - <u, v>_L )
Equation (6)  exp_o(h) = cosh(||h||) o + sinh(||h||) h / ||h||
Equation (7)  x_i^(l+1) = exp_o( sum_j a_ij log_o( x_j^(l) ) )
Equation (8)  psi(t) = arcsin( 2K / ||t|| )

Points live on the upper sheet of the hyperboloid
    <x, x>_L = -1,   <u, v>_L = -u_0 v_0 + sum_k u_k v_k
with the origin o = (1, 0, ..., 0).
"""
from __future__ import annotations
import torch

EPS = 1e-7
MAX_NORM = 40.0


def minkowski_dot(u: torch.Tensor, v: torch.Tensor, keepdim: bool = False) -> torch.Tensor:
    """Lorentz inner product <u, v>_L."""
    prod = u * v
    res = prod[..., 1:].sum(dim=-1) - prod[..., 0]
    return res.unsqueeze(-1) if keepdim else res


def lorentz_distance(u: torch.Tensor, v: torch.Tensor) -> torch.Tensor:
    """Equation (5)."""
    inner = -minkowski_dot(u, v)
    return torch.acosh(torch.clamp(inner, min=1.0 + EPS))


def exp_map_origin(h: torch.Tensor) -> torch.Tensor:
    """Equation (6). h is a tangent vector at the origin, given by its spatial part."""
    norm = torch.clamp(h.norm(dim=-1, keepdim=True), min=EPS, max=MAX_NORM)
    time = torch.cosh(norm)
    space = torch.sinh(norm) * h / norm
    return torch.cat([time, space], dim=-1)


def log_map_origin(x: torch.Tensor) -> torch.Tensor:
    """Inverse of equation (6): returns the spatial part of the tangent vector."""
    time = torch.clamp(x[..., :1], min=1.0 + EPS)
    space = x[..., 1:]
    norm = torch.clamp(space.norm(dim=-1, keepdim=True), min=EPS)
    return torch.acosh(time) * space / norm


def project_to_hyperboloid(x: torch.Tensor) -> torch.Tensor:
    """Restore <x, x>_L = -1 after a numerically noisy update."""
    space = x[..., 1:]
    time = torch.sqrt(1.0 + (space * space).sum(dim=-1, keepdim=True))
    return torch.cat([time, space], dim=-1)


def hyperbolic_norm(x: torch.Tensor) -> torch.Tensor:
    """Distance from the origin. Carries the level of abstraction of a concept."""
    return torch.acosh(torch.clamp(x[..., 0], min=1.0 + EPS))


def cone_half_angle(x: torch.Tensor, K: float) -> torch.Tensor:
    """Equation (8). Defined only where ||t|| >= 2K, which the caller enforces."""
    norm = torch.clamp(hyperbolic_norm(x), min=2.0 * K + EPS)
    return torch.asin(torch.clamp(2.0 * K / norm, max=1.0 - EPS))


def enforce_cone_radius(h: torch.Tensor, K: float) -> torch.Tensor:
    """Push tangent vectors out to the ball of radius 2K so equation (8) is defined."""
    norm = h.norm(dim=-1, keepdim=True)
    floor = 2.0 * K + 1e-3
    scale = torch.where(norm < floor, floor / torch.clamp(norm, min=EPS), torch.ones_like(norm))
    return h * scale


def cone_angle(child: torch.Tensor, parent: torch.Tensor) -> torch.Tensor:
    """Angle between the geodesic from parent to child and the radial direction.

    Uses the standard expression for the exterior angle on the hyperboloid.
    """
    inner = -minkowski_dot(parent, child)
    num = child[..., 0] - parent[..., 0] * inner
    denom = torch.clamp(hyperbolic_norm(parent), min=EPS) * torch.sqrt(
        torch.clamp(inner * inner - 1.0, min=EPS))
    cos = torch.clamp(num / torch.clamp(denom, min=EPS), min=-1.0 + EPS, max=1.0 - EPS)
    return torch.acos(cos)
