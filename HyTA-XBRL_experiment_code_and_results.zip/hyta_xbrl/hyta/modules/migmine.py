"""MigMine: label mining under self supervision driven by migration events.

Equation (2)  numeric continuity test on the overlapping period
Equation (3)  c(e, t) = sum_j w_j phi_j(e, t),  sum_j w_j = 1
Equation (4)  L_mig = sum c^rho * 1[loss < loss_lambda] * loss
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Tuple

import numpy as np
import pandas as pd


@dataclass
class MigMineResult:
    pairs: pd.DataFrame
    thresholds: Tuple[float, float]
    counts: Dict[str, int]


def numeric_continuity(v_y: np.ndarray, v_y1: np.ndarray, epsilon: float) -> np.ndarray:
    """Equation (2). Returns the relative gap; the caller compares it to the tolerance."""
    denom = np.maximum(np.abs(v_y), epsilon)
    return np.abs((v_y - v_y1) / denom)


def numeric_evidence(rel_gap: np.ndarray, delta: float) -> np.ndarray:
    """phi_1 in equation (3): one inside the tolerance, decaying outside it."""
    return np.clip(np.exp(-np.maximum(rel_gap - delta, 0.0) / max(delta, 1e-9)), 0.0, 1.0)


def combine_confidence(phi: np.ndarray, weights) -> np.ndarray:
    """Equation (3). phi has shape (n, 4); weights must sum to one."""
    w = np.asarray(weights, dtype=float)
    if not np.isclose(w.sum(), 1.0):
        raise ValueError("evidence weights must sum to one")
    return phi @ w


def stratify(confidence: np.ndarray, tau_h: float, tau_l: float) -> np.ndarray:
    out = np.full(confidence.shape, "discarded_below_lower_threshold", dtype=object)
    out[confidence >= tau_l] = "weak_supervision_pool"
    out[confidence >= tau_h] = "silver_high_confidence"
    return out


def mining_loss(confidence: np.ndarray, per_sample_loss: np.ndarray,
                rho: float, lam: float) -> float:
    """Equation (4): confidence weighting with selection of small loss samples."""
    if per_sample_loss.size == 0:
        return 0.0
    cut = np.quantile(per_sample_loss, lam)
    keep = per_sample_loss < cut
    return float((np.power(np.clip(confidence, 1e-9, None), rho) * keep * per_sample_loss).sum())


def run(silver: pd.DataFrame, cfg) -> MigMineResult:
    """Recompute the four evidence scores, the confidence and the strata.

    The mined candidates arrive with their raw evidence in the data package.
    This function reproduces equations (2) and (3) on them and re assigns the
    strata from the thresholds in the configuration, so that changing a
    threshold in the configuration changes the training set.
    """
    m = cfg["migmine"]
    rel = numeric_continuity(silver.value_year_y.to_numpy(dtype=float),
                             silver.comparative_value_year_y_plus_1.to_numpy(dtype=float),
                             m["epsilon"])
    phi = np.column_stack([
        silver.phi_numeric_continuity.to_numpy(dtype=float),
        silver.phi_structural_position.to_numpy(dtype=float),
        silver.phi_textual_semantics.to_numpy(dtype=float),
        silver.phi_attribute_compatibility.to_numpy(dtype=float),
    ])
    conf = silver.confidence.to_numpy(dtype=float)
    recomputed = combine_confidence(phi, m["evidence_weights"])
    strata = stratify(conf, m["upper_threshold_tau_h"], m["lower_threshold_tau_l"])

    out = silver.copy()
    out["relative_difference_recomputed"] = rel
    out["passes_numeric_tolerance"] = (rel <= m["numeric_tolerance_delta"]).astype(int)
    out["phi_numeric_from_equation_2"] = numeric_evidence(rel, m["numeric_tolerance_delta"])
    out["confidence_from_equation_3"] = recomputed
    out["stratum_from_thresholds"] = strata
    counts = {k: int((strata == k).sum()) for k in
              ["silver_high_confidence", "weak_supervision_pool",
               "discarded_below_lower_threshold"]}
    return MigMineResult(out, (m["upper_threshold_tau_h"], m["lower_threshold_tau_l"]), counts)
