"""HypeRank: hierarchical encoding on the Lorentz manifold and graded ranking.

Equation (9)   s(e, t) = - d(x_e, x_t) - beta * max(0, theta - psi(x_t))
Equation (10)  r(e, t) = gamma ^ k(t*, t)
Equation (11)  L_rank = sum [ m (r_a - r_b) - (s_a - s_b) ]_+
"""
from __future__ import annotations
import hashlib
import re
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn

from . import lorentz as L

_TOKEN = re.compile(r"[a-z0-9]+")


# --------------------------------------------------------------------- text
class HashingTextEncoder:
    """Deterministic character and word n gram sketch.

    The manuscript initialises the encoder from an open source sentence
    embedding model. That model is a network dependency, so the default backend
    here is a hashing sketch that needs no download and is bit for bit
    reproducible. Set encoder.backend to sentence_transformers to swap it.
    """

    def __init__(self, dim: int = 4096, char_ngrams=(3, 4, 5), word_ngrams=(1, 2)):
        self.dim = int(dim)
        self.char_ngrams = tuple(char_ngrams)
        self.word_ngrams = tuple(word_ngrams)

    def _features(self, text: str) -> List[str]:
        t = str(text).lower()
        words = _TOKEN.findall(t)
        feats: List[str] = []
        for n in self.word_ngrams:
            feats += ["w%d:%s" % (n, " ".join(words[i:i + n])) for i in range(max(len(words) - n + 1, 0))]
        packed = " ".join(words)
        for n in self.char_ngrams:
            feats += ["c%d:%s" % (n, packed[i:i + n]) for i in range(max(len(packed) - n + 1, 0))]
        return feats

    def encode(self, texts) -> np.ndarray:
        out = np.zeros((len(texts), self.dim), dtype=np.float32)
        for i, text in enumerate(texts):
            for f in self._features(text):
                h = int.from_bytes(hashlib.blake2b(f.encode(), digest_size=8).digest(), "little")
                out[i, h % self.dim] += 1.0 if (h >> 63) & 1 == 0 else -1.0
        norm = np.linalg.norm(out, axis=1, keepdims=True)
        return out / np.maximum(norm, 1e-9)


def build_encoder(cfg) -> HashingTextEncoder:
    e = cfg["encoder"]
    if e["backend"] == "sentence_transformers":       # optional path
        try:
            from sentence_transformers import SentenceTransformer

            class _ST:
                def __init__(self):
                    self.m = SentenceTransformer(e.get("model_name", "all-MiniLM-L6-v2"))

                def encode(self, texts):
                    v = self.m.encode(list(texts), normalize_embeddings=True)
                    return np.asarray(v, dtype=np.float32)

            return _ST()
        except Exception as exc:                       # pragma: no cover
            print(f"    sentence_transformers unavailable ({exc}); falling back to hashing")
    return HashingTextEncoder(e["hash_dim"], e["char_ngrams"], e["word_ngrams"])


# ------------------------------------------------------------------ model
class HyperbolicGraphPropagation(nn.Module):
    """Equation (7): aggregate in the tangent space, map back onto the manifold."""

    def __init__(self, layers: int):
        super().__init__()
        self.layers = layers
        self.att = nn.ParameterList([nn.Parameter(torch.tensor(0.5)) for _ in range(layers)])

    def forward(self, x: torch.Tensor, parent_index: torch.Tensor) -> torch.Tensor:
        for l in range(self.layers):
            tangent = L.log_map_origin(x)
            parent_tangent = torch.where(
                (parent_index >= 0).unsqueeze(-1),
                tangent[parent_index.clamp(min=0)],
                tangent)
            a = torch.sigmoid(self.att[l])
            mixed = (1.0 - a) * tangent + a * parent_tangent
            x = L.exp_map_origin(mixed)
        return x


class HypeRank(nn.Module):
    def __init__(self, in_dim: int, hyp_dim: int, layers: int, K: float, beta: float,
                 euclidean: bool = False, use_cone: bool = True):
        super().__init__()
        self.project = nn.Linear(in_dim, hyp_dim, bias=False)
        self.scale = nn.Parameter(torch.tensor(1.0))
        self.prop = HyperbolicGraphPropagation(layers)
        self.K = float(K)
        self.beta = float(beta)
        self.euclidean = bool(euclidean)
        self.use_cone = bool(use_cone)
        nn.init.normal_(self.project.weight, std=0.02)

    def embed(self, features: torch.Tensor, parent_index: Optional[torch.Tensor] = None) -> torch.Tensor:
        h = self.project(features) * torch.clamp(self.scale, min=0.1, max=8.0)
        if self.euclidean:
            return h
        h = L.enforce_cone_radius(h, self.K) if self.use_cone else h
        x = L.exp_map_origin(h)
        if parent_index is not None:
            x = self.prop(x, parent_index)
            x = L.project_to_hyperboloid(x)
        return x

    def score(self, source: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        """Equation (9)."""
        if self.euclidean:
            return -(source - target).norm(dim=-1)
        d = L.lorentz_distance(source, target)
        if not self.use_cone:
            return -d
        psi = L.cone_half_angle(target, self.K)
        theta = L.cone_angle(source, target)
        return -d - self.beta * torch.clamp(theta - psi, min=0.0)


# ------------------------------------------------------------------ losses
def graded_relevance(tree_distance: torch.Tensor, gamma: float, cutoff: int) -> torch.Tensor:
    """Equation (10). Candidates beyond the cutoff score zero."""
    rel = torch.pow(torch.tensor(float(gamma)), tree_distance.to(torch.float32))
    return torch.where(tree_distance <= cutoff, rel, torch.zeros_like(rel))


def listwise_margin_loss(scores: torch.Tensor, relevance: torch.Tensor, margin: float) -> torch.Tensor:
    """Equation (11): every ordered pair with r_a > r_b contributes a hinge."""
    s_a = scores.unsqueeze(2)
    s_b = scores.unsqueeze(1)
    r_a = relevance.unsqueeze(2)
    r_b = relevance.unsqueeze(1)
    gap = r_a - r_b
    mask = (gap > 0).to(scores.dtype)
    hinge = torch.clamp(margin * gap - (s_a - s_b), min=0.0)
    denom = torch.clamp(mask.sum(), min=1.0)
    return (hinge * mask).sum() / denom


@dataclass
class TrainReport:
    epochs: List[int]
    losses: List[float]
    mean_rank_gain: float


def train(model: HypeRank,
          source_feats: torch.Tensor,
          target_feats: torch.Tensor,
          target_parent: torch.Tensor,
          candidate_index: np.ndarray,
          tree_distance: np.ndarray,
          sample_weight: np.ndarray,
          cfg) -> TrainReport:
    """Train HypeRank on the silver standard with equations (9) to (11)."""
    h = cfg["hyperank"]
    opt = torch.optim.Adam(model.parameters(), lr=h["learning_rate"], weight_decay=h["weight_decay"])
    n = source_feats.shape[0]
    order = np.arange(n)
    losses, epochs = [], []
    td = torch.from_numpy(tree_distance.astype(np.int64))
    ci = torch.from_numpy(candidate_index.astype(np.int64))
    w = torch.from_numpy(sample_weight.astype(np.float32))
    for ep in range(h["epochs"]):
        np.random.shuffle(order)
        running, steps = 0.0, 0
        for start in range(0, n, h["batch_size"]):
            idx = order[start:start + h["batch_size"]]
            if len(idx) < 4:
                continue
            src = model.embed(source_feats[idx])
            tgt_all = model.embed(target_feats, target_parent)
            cand = ci[idx]
            tgt = tgt_all[cand]
            s = model.score(src.unsqueeze(1).expand(-1, cand.shape[1], -1), tgt)
            rel = graded_relevance(td[idx], h["graded_discount_gamma"], h["tree_distance_cutoff"])
            loss = listwise_margin_loss(s, rel, h["base_margin_m"])
            loss = loss * w[idx].mean()
            opt.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
            running += float(loss.detach())
            steps += 1
        losses.append(running / max(steps, 1))
        epochs.append(ep + 1)
        print(f"    epoch {ep + 1}/{h['epochs']}  L_rank = {losses[-1]:.5f}", flush=True)
    gain = (losses[0] - losses[-1]) / max(losses[0], 1e-9) if losses else 0.0
    return TrainReport(epochs, losses, float(gain))
