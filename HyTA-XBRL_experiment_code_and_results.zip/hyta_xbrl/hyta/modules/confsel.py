"""ConfSel: split conformal selective prediction.

Equation (16)  tau_alpha = Quantile( {a_i}, ceil((n+1)(1-alpha)) / n )
Equation (17)  f(e) = argmax s(e,t) if a(e) <= tau_alpha, else abstain
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Tuple

import numpy as np


@dataclass
class ConformalResult:
    threshold: float
    retained: np.ndarray
    coverage: float
    selective_accuracy: float
    empirical_error: float


def nonconformity(top_score: np.ndarray, second_score: np.ndarray,
                  gap_weight: float, top_weight: float) -> np.ndarray:
    """Combines the top one to top two gap with the normalised top score.

    The score grows as reliability falls, which is the orientation equation (17)
    expects. The gap carries aleatoric ambiguity between close candidates, the
    normalised top score carries the epistemic side.
    """
    gap = top_score - second_score
    lo, hi = np.percentile(top_score, [1, 99])
    norm_top = np.clip((top_score - lo) / max(hi - lo, 1e-9), 0.0, 1.0)
    return -(gap_weight * gap + top_weight * norm_top)


def conformal_threshold(calibration_scores: np.ndarray, alpha: float) -> float:
    """Equation (16)."""
    n = len(calibration_scores)
    if n == 0:
        return np.inf
    level = np.ceil((n + 1) * (1.0 - alpha)) / n
    level = float(min(level, 1.0))
    return float(np.quantile(calibration_scores, level, method="higher"))


def apply(test_scores: np.ndarray, correct: np.ndarray, threshold: float) -> ConformalResult:
    """Equation (17) and the two reliability metrics of Table 4."""
    retained = test_scores <= threshold
    coverage = float(retained.mean())
    if retained.sum() == 0:
        return ConformalResult(threshold, retained, 0.0, 0.0, 0.0)
    sel_acc = float(correct[retained].mean())
    return ConformalResult(threshold, retained, coverage, sel_acc, 1.0 - sel_acc)


def split_conformal(scores: np.ndarray, correct: np.ndarray, alpha: float,
                    calibration_fraction: float, rng: np.random.Generator
                    ) -> Tuple[ConformalResult, np.ndarray]:
    """Split the sample, calibrate on one half, decide on the other.

    Selection destroys exchangeability, so the calibration set is scored with
    the same selection rule as the test set before the quantile is taken.
    """
    n = len(scores)
    idx = rng.permutation(n)
    n_cal = max(int(round(calibration_fraction * n)), 20)
    cal, test = idx[:n_cal], idx[n_cal:]
    tau = conformal_threshold(scores[cal], alpha)
    res = apply(scores[test], correct[test], tau)
    return res, test
