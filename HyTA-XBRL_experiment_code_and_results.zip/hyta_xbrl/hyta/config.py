"""Configuration loading."""
from __future__ import annotations
import os
from dataclasses import dataclass
from typing import Any, Dict
import yaml

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _resolve(path: str) -> str:
    return path if os.path.isabs(path) else os.path.normpath(os.path.join(ROOT, path))


@dataclass
class Config:
    raw: Dict[str, Any]

    def __getitem__(self, key: str) -> Any:
        return self.raw[key]

    def get(self, key: str, default: Any = None) -> Any:
        return self.raw.get(key, default)

    @property
    def data_dir(self) -> str:
        return _resolve(self.raw["project"]["data_dir"])

    @property
    def results_dir(self) -> str:
        p = _resolve(self.raw["project"]["results_dir"])
        os.makedirs(p, exist_ok=True)
        return p

    @property
    def cache_dir(self) -> str:
        p = _resolve(self.raw["project"]["cache_dir"])
        os.makedirs(p, exist_ok=True)
        return p

    def data_path(self, filename: str) -> str:
        return os.path.join(self.data_dir, filename)

    def anchors(self) -> Dict[str, Any]:
        with open(_resolve(self.raw["reference_alignment"]["anchors_file"]), "r") as fh:
            return yaml.safe_load(fh)


def load_config(path: str = "configs/default.yaml", overrides: Dict[str, Any] | None = None) -> Config:
    with open(_resolve(path), "r") as fh:
        raw = yaml.safe_load(fh)
    if overrides:
        for dotted, value in overrides.items():
            node = raw
            keys = dotted.split(".")
            for k in keys[:-1]:
                node = node.setdefault(k, {})
            node[keys[-1]] = value
    if os.environ.get("HYTA_DATA_DIR"):
        raw["project"]["data_dir"] = os.environ["HYTA_DATA_DIR"]
    return Config(raw)
