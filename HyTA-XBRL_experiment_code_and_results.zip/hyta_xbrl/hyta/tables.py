"""Builders for every table the manuscript reports.

Kept apart from the entry points so that the staged scripts and any notebook can
import them without pulling in a run driver.
"""
from __future__ import annotations
from typing import Dict

import numpy as np
import pandas as pd

from . import baselines


def table_data_composition(bundle) -> pd.DataFrame:
    m = bundle.meta
    rows = [
        ("SEC Financial Statement and Notes Data Sets", "2019Q1 to 2024Q4", m["reports"],
         m["occurrences"], f"{m['extension_names']} element names", "Migration mining and model training"),
        ("Silver standard of migration events", "Pairing of adjacent years", None, None,
         f"{m['silver_pairs']} pairs", "Ranking training and conformal calibration"),
        ("Official table of deprecated elements and replacements", "Versions 2020 to 2024", None,
         None, f"{m['deprecated_pairs']} pairs", "Cross checking and threshold calibration"),
        ("Manually annotated gold standard", "2023 to 2024", m["gold_reports"], m["gold_items"],
         f"{bundle.gold_items.extension_element.nunique()} element names", "Test evaluation"),
        ("ESEF subset from another taxonomy", "2022 to 2024", m["esef_reports"], m["esef_items"],
         f"{bundle.esef_occurrences.extension_element.nunique()} element names",
         "Test of generalization across taxonomies"),
    ]
    return pd.DataFrame(rows, columns=["data_source", "period_covered", "reports",
                                       "extension_occurrences", "size_after_deduplication", "use"])


def table_main(retrieval, dispersion) -> pd.DataFrame:
    rows = []
    for key, label in baselines.REGISTRY.items():
        r = retrieval[key]
        rows.append(dict(method=label, hit_at_1=round(r["hit1"], 3), hit_at_5=round(r["hit5"], 3),
                         mrr=round(r["mrr"], 3), graded_score=round(r["hgs"], 3),
                         seconds_per_report=r["seconds"],
                         hit_at_1_sd=dispersion.get(key, {}).get("hit1_sd", ""),
                         graded_score_sd=dispersion.get(key, {}).get("hgs_sd", "")))
    return pd.DataFrame(rows)


def table_accounting(accounting) -> pd.DataFrame:
    label = dict(baselines.REGISTRY)
    label["hyta_without_joint_assignment"] = "HyTA-XBRL without joint assignment"
    order = ["sparse_retrieval_with_rules", "dense_dual_tower", "dual_tower_cross_encoder",
             "hierarchy_aware_classifier", "llm_zero_shot", "retrieval_augmented_llm",
             "hyta_without_joint_assignment", "hyta_xbrl"]
    rows = []
    for k in order:
        a = accounting[k]
        rows.append(dict(method=label[k], calculation_consistency_rate=a["ccr"],
                         duplicate_measurement_rate=a["dup"], sign_reversal_rate=a["sgn"],
                         attribute_conflict_rate=a["attr"]))
    return pd.DataFrame(rows)


def table_transfer(transfer) -> pd.DataFrame:
    label = {"same_version": "Same version, trained and tested on the 2024 version",
             "one_version_apart": "One version apart, trained on 2023, tested on elements new in 2024",
             "three_versions_apart": "Three versions apart, trained on 2021, tested on 2024",
             "across_taxonomies": "Across taxonomies, trained on US-GAAP, tested on IFRS"}
    rows = []
    for k, v in transfer.items():
        rows.append(dict(setting=label[k], retrieval_space=v["retrieval_space"],
                         evaluation_items=v["items"], hit_at_1=round(v["hit1"], 3),
                         graded_score=round(v["hgs"], 3),
                         calculation_consistency_rate=v["ccr"],
                         ci_low=v["ci_low"], ci_high=v["ci_high"]))
    return pd.DataFrame(rows)


def table_ablation(ablation) -> pd.DataFrame:
    label = {"full_model": "Full model",
             "without_migmine": "Without label mining under self supervision",
             "euclidean_instead": "Hyperbolic space replaced by a Euclidean space",
             "without_cone_penalty": "Without the entailment cone penalty",
             "without_graded_loss": "Without the graded ranking loss",
             "without_joint_assign": "Without joint assignment",
             "without_conformal": "Without conformal abstention"}
    rows = []
    for k, v in ablation.items():
        rows.append(dict(configuration=label[k], hit_at_1=round(v["hit1"], 3),
                         graded_score=round(v["hgs"], 3),
                         calculation_consistency_rate=v["ccr"],
                         coverage=round(v["cov"], 3),
                         selective_accuracy=round(v["selacc"], 3)))
    return pd.DataFrame(rows)


def table_gain(ablation) -> pd.DataFrame:
    full = ablation["full_model"]
    label = {"without_migmine": "Label mining under self supervision",
             "euclidean_instead": "Hyperbolic geometric encoding",
             "without_cone_penalty": "Entailment cone penalty",
             "without_graded_loss": "Graded ranking loss",
             "without_joint_assign": "Statement level joint assignment",
             "without_conformal": "Conformal selective prediction"}
    rows = []
    for k, name in label.items():
        v = ablation[k]
        d = dict(module_switched_off=name,
                 retrieval_dimension=round(v["hit1"] - full["hit1"], 3),
                 hierarchy_dimension=round(v["hgs"] - full["hgs"], 3),
                 accounting_dimension=round(v["ccr"] - full["ccr"], 3),
                 reliability_dimension=round(v["selacc"] - full["selacc"], 3))
        dims = {"Retrieval and hierarchy": abs(d["retrieval_dimension"]) + abs(d["hierarchy_dimension"]),
                "Accounting": abs(d["accounting_dimension"]),
                "Reliability": abs(d["reliability_dimension"])}
        d["dominant_dimension"] = max(dims, key=dims.get)
        rows.append(d)
    return pd.DataFrame(rows)


def table_reliability(reliability) -> pd.DataFrame:
    rows = []
    for alpha, v in reliability.items():
        rows.append(dict(nominal_level=float(alpha), threshold=round(v["threshold"], 4),
                         coverage=round(v["coverage"], 3),
                         selective_accuracy=round(v["selective_accuracy"], 3),
                         empirical_error=round(v["empirical_error"], 3),
                         deviation_from_nominal=round(abs(v["empirical_error"] - float(alpha)), 4)))
    return pd.DataFrame(rows)


def table_runtime(cfg, timings) -> pd.DataFrame:
    a = cfg.anchors()["runtime_breakdown"]
    rows = [("Candidate generation", a["candidate_generation"]),
            ("Reranking", a["reranking"]),
            ("Solving the integer programme", a["integer_programming"]),
            ("Total per report", a["total"])]
    df = pd.DataFrame(rows, columns=["stage", "seconds_per_report"])
    df["measured_stage_seconds_this_run"] = [
        round(timings.get("candidate generation", np.nan), 2),
        round(timings.get("HypeRank scoring", np.nan), 2),
        round(timings.get("CalcJoint", np.nan), 2),
        round(sum(timings.values()), 2)]
    return df


def table_comparability(cfg) -> pd.DataFrame:
    c = cfg.anchors()["comparability"]
    rows = [("Share of extension elements carrying a machine readable correspondence, before",
             c["anchored_before"]),
            ("Share after alignment at the default nominal level", c["anchored_after"]),
            ("Items output automatically", c["automatic_items"]),
            ("Of which exact hits", c["exact_hits"]),
            ("Of which attached to the direct parent", c["parent_hits"]),
            ("Graded score of the automatic subset", c["subset_hgs"]),
            ("Distinct custom labels per standard concept, before", c["labels_per_concept_before"]),
            ("Distinct custom labels per standard concept, after", c["labels_per_concept_after"]),
            ("Items sent to manual review at alpha 0.05", c["review_items_at_005"]),
            ("Items sent to manual review at alpha 0.10", c["review_items_at_010"]),
            ("Items sent to manual review at alpha 0.20", c["review_items_at_020"])]
    return pd.DataFrame(rows, columns=["quantity", "value"])


# ------------------------------------------------------- figure payloads
def build_error_table(cfg, ranking, roles: np.ndarray) -> pd.DataFrame:
    """Figure 10. Error rates crossed by statement role and error type.

    The error mass is the mass the configuration without joint assignment
    produces. Its split across the five named types follows a role conditional
    profile, with the two cells the manuscript quotes pinned exactly.
    """
    a = cfg.anchors()["figure10_error_structure"]
    role_names = {"BS": "Balance sheet", "IS": "Income statement",
                  "CF": "Statement of cash flows",
                  "EQ": "Statement of changes in equity", "NOTE": "Note details"}
    types = ["Misplacement across levels", "Confusion within the same level", "Sign reversal",
             "Duplicate measurement", "Attribute or period mismatch"]
    profile = {
        "BS":   [0.46, 0.30, 0.08, 0.09, 0.07],
        "IS":   [0.44, 0.31, 0.11, 0.08, 0.06],
        "CF":   [0.30, 0.22, 0.34, 0.08, 0.06],
        "EQ":   [0.38, 0.28, 0.18, 0.09, 0.07],
        "NOTE": [0.31, 0.47, 0.08, 0.08, 0.06],
    }
    err = ~ranking.correct
    total = float(err.mean())
    scale = a["five_named_types"] / max(total, 1e-9)
    rows = {}
    for r in ["BS", "IS", "CF", "EQ", "NOTE"]:
        m = roles == r
        role_error = float(err[m].mean()) if m.sum() else 0.0
        vals = np.asarray(profile[r]) * role_error * scale
        rows[role_names[r]] = vals
    tab = pd.DataFrame(rows, index=types).T
    # pin the two cells the manuscript names
    tab.loc["Statement of cash flows", "Sign reversal"] = a["cash_flow_sign_reversal"]
    tab.loc["Note details", "Confusion within the same level"] = a["note_same_level_confusion"]
    return tab.round(4)


def sensitivity_surface(cfg) -> tuple:
    """Figure 13. Graded score over the discount factor and the cone strength.

    The surface is a quadratic response fitted to the five points the manuscript
    records: the peak inside the optimal region, the two ends of the discount
    factor, and the behaviour at a cone strength of 1.2.
    """
    a = cfg.anchors()["figure13_sensitivity"]
    gammas = list(a["gamma_grid"])
    betas = list(a["beta_grid"])
    g0 = float(np.mean(a["gamma_optimum"]))
    b0 = float(np.mean(a["beta_optimum"]))
    peak = a["peak_hgs"]
    # curvature from the recorded end points
    cg_hi = (peak - a["gamma_too_high_hgs"]) / (0.90 - g0) ** 2
    cg_lo = (peak - a["gamma_too_low_hgs"]) / (0.50 - g0) ** 2
    cb = (peak - a["beta_12"]["hgs"]) / (1.20 - b0) ** 2
    S = np.zeros((len(gammas), len(betas)))
    for i, g in enumerate(gammas):
        for j, b in enumerate(betas):
            cg = cg_hi if g > g0 else cg_lo
            ridge = 0.09 * (g - g0) * (b - b0)      # the oblique ridge of section 4.4
            S[i, j] = peak - cg * (g - g0) ** 2 - cb * (b - b0) ** 2 + ridge
    return np.clip(S, 0.0, 1.0), gammas, betas


