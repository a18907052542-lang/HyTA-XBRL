"""Target space, presentation forest, calculation forest and tree distance.

The tree distance used by equation (10) is the length of the shortest path
between two elements on the taxonomy tree. It is computed on the presentation
forest of the release, which is the structure the manuscript describes.
"""
from __future__ import annotations
from collections import defaultdict, deque
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd


class Taxonomy:
    def __init__(self, elements: pd.DataFrame, pres_arcs: pd.DataFrame, calc_arcs: pd.DataFrame):
        self.elements = elements.reset_index(drop=True)
        self.name_to_idx: Dict[str, int] = {n: i for i, n in enumerate(self.elements.element_name)}
        self.idx_to_name: List[str] = list(self.elements.element_name)
        self.pres_arcs = pres_arcs
        self.calc_arcs = calc_arcs

        self.parent = np.full(len(self.elements), -1, dtype=np.int64)
        for child, par in zip(self.elements.element_name, self.elements.presentation_parent):
            if isinstance(par, str) and par in self.name_to_idx:
                self.parent[self.name_to_idx[child]] = self.name_to_idx[par]
        self.depth = self.elements.depth.fillna(0).to_numpy().astype(np.int64)
        self.statement_role = self.elements.statement_role.fillna("NOTE").to_numpy()
        self.period_type = self.elements.period_type.fillna("duration").to_numpy()
        self.balance = self.elements.balance.fillna("").to_numpy()

        self.calc_parent = np.full(len(self.elements), -1, dtype=np.int64)
        self.calc_weight = np.zeros(len(self.elements), dtype=np.float64)
        for child, par, w in zip(self.elements.element_name,
                                 self.elements.calculation_parent,
                                 self.elements.calculation_weight):
            if isinstance(par, str) and par in self.name_to_idx:
                i = self.name_to_idx[child]
                self.calc_parent[i] = self.name_to_idx[par]
                self.calc_weight[i] = float(w) if not pd.isna(w) else 1.0

        self.children = defaultdict(list)
        for i, p in enumerate(self.parent):
            if p >= 0:
                self.children[int(p)].append(i)
        self._anc_cache: Dict[int, List[int]] = {}

    # ---------------------------------------------------------------- tree
    def ancestors(self, i: int, max_levels: int = 32) -> List[int]:
        if i in self._anc_cache:
            return self._anc_cache[i]
        out, cur, guard = [], int(self.parent[i]), 0
        while cur >= 0 and guard < max_levels:
            out.append(cur)
            cur = int(self.parent[cur])
            guard += 1
        self._anc_cache[i] = out
        return out

    def tree_distance(self, a: int, b: int, cutoff: int = 6) -> int:
        """Shortest path length on the presentation forest, capped at cutoff + 1."""
        if a == b:
            return 0
        pa = [a] + self.ancestors(a)
        pb = [b] + self.ancestors(b)
        pos_b = {n: k for k, n in enumerate(pb)}
        for k, n in enumerate(pa):
            if n in pos_b:
                d = k + pos_b[n]
                return d if d <= cutoff else cutoff + 1
        return cutoff + 1

    def tree_distance_many(self, a: int, bs: np.ndarray, cutoff: int = 6) -> np.ndarray:
        pa = [a] + self.ancestors(a)
        pos_a = {n: k for k, n in enumerate(pa)}
        out = np.full(len(bs), cutoff + 1, dtype=np.int64)
        for j, b in enumerate(bs):
            b = int(b)
            if b == a:
                out[j] = 0
                continue
            pb = [b] + self.ancestors(b)
            best = cutoff + 1
            for k, n in enumerate(pb):
                if n in pos_a:
                    best = min(best, k + pos_a[n])
                    break
            out[j] = best if best <= cutoff else cutoff + 1
        return out

    # ------------------------------------------------------- calculation
    def calculation_groups(self) -> Dict[int, List[int]]:
        groups = defaultdict(list)
        for i, p in enumerate(self.calc_parent):
            if p >= 0:
                groups[int(p)].append(i)
        return groups

    def __len__(self) -> int:
        return len(self.elements)
