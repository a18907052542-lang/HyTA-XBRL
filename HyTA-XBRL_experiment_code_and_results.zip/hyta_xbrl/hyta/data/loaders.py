"""Readers for the twenty two files of the data package."""
from __future__ import annotations
import os
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from ..config import Config
from .taxonomy import Taxonomy


@dataclass
class DataBundle:
    taxonomy: Taxonomy
    target_text: pd.DataFrame
    extension_dictionary: pd.DataFrame
    extension_text: pd.DataFrame
    reports: pd.DataFrame
    filers: pd.DataFrame
    silver: pd.DataFrame
    gold_reports: pd.DataFrame
    gold_items: pd.DataFrame
    gold_occurrences: pd.DataFrame
    esef_reports: pd.DataFrame
    esef_occurrences: pd.DataFrame
    ifrs_space: pd.DataFrame
    deprecated_pairs: pd.DataFrame
    splits: pd.DataFrame
    meta: Dict[str, int] = field(default_factory=dict)


def _read(cfg: Config, key_group: str, key: str, **kw) -> pd.DataFrame:
    path = cfg.data_path(cfg[key_group][key])
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"{path} not found. Unpack the data package into {cfg.data_dir}."
        )
    return pd.read_csv(path, **kw)


def load_gold_occurrences(cfg: Config, accessions: set) -> pd.DataFrame:
    """Occurrence rows of the gold standard reports, read year by year."""
    frames = []
    for year in cfg["corpus"]["occurrence_years"]:
        path = cfg.data_path(cfg["corpus"]["occurrence_pattern"].format(year=year))
        if not os.path.exists(path):
            continue
        for chunk in pd.read_csv(path, chunksize=400_000):
            sel = chunk[chunk.accession_number.isin(accessions)]
            if len(sel):
                frames.append(sel)
    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)


def load_bundle(cfg: Config, with_occurrences: bool = True,
                light: bool = False) -> DataBundle:
    tax_elements = _read(cfg, "taxonomy", "target_space_file")
    pres = _read(cfg, "taxonomy", "presentation_arcs_file")
    calc = _read(cfg, "taxonomy", "calculation_arcs_file")
    taxonomy = Taxonomy(tax_elements, pres, calc)

    target_text = _read(cfg, "corpus", "target_text_file",
                        usecols=["element_id", "encoder_input_text"])
    # the extension dictionary and its text records are only needed the first
    # time, when the encoder sketch is built; afterwards the cache is read
    if light:
        ext_dict = pd.DataFrame(columns=["ext_id", "element_name"])
        ext_text = pd.DataFrame(columns=["ext_id", "encoder_input_text"])
    else:
        ext_dict = _read(cfg, "corpus", "extension_dictionary_file",
                         usecols=["ext_id", "element_name", "data_type", "period_type",
                                  "balance", "n_report_occurrences"])
        ext_text = _read(cfg, "corpus", "extension_text_file",
                         usecols=["ext_id", "encoder_input_text"])
    reports = _read(cfg, "corpus", "report_index_file")
    filers = _read(cfg, "corpus", "filer_master_file")
    silver = _read(cfg, "corpus", "silver_file",
                   usecols=["pair_id", "extension_element", "ext_id", "statement_role",
                            "target_element", "value_year_y",
                            "comparative_value_year_y_plus_1",
                            "phi_numeric_continuity", "phi_structural_position",
                            "phi_textual_semantics", "phi_attribute_compatibility",
                            "confidence", "stratum", "fiscal_year_y"])
    gold_reports = _read(cfg, "corpus", "gold_reports_file")
    gold_items = _read(cfg, "corpus", "gold_annotations_file")
    esef_reports = _read(cfg, "corpus", "esef_reports_file")
    esef_occ = _read(cfg, "corpus", "esef_occurrences_file")
    ifrs = _read(cfg, "taxonomy", "ifrs_space_file")
    dep = _read(cfg, "taxonomy", "deprecated_pairs_file")
    splits = _read(cfg, "corpus", "split_file")

    gold_occ = pd.DataFrame()
    if with_occurrences:
        gold_occ = load_gold_occurrences(cfg, set(gold_reports.accession_number))

    meta = dict(
        target_space=len(tax_elements),
        reports=len(reports),
        filers=len(filers),
        extension_names=len(ext_dict) if len(ext_dict) else 412573,
        occurrences=int(reports.n_extension_elements.sum()),
        silver_pairs=int((silver.stratum == "silver_high_confidence").sum()),
        gold_reports=len(gold_reports),
        gold_items=len(gold_items),
        esef_reports=len(esef_reports),
        esef_items=len(esef_occ),
        ifrs_space=len(ifrs),
        deprecated_pairs=len(dep),
    )
    return DataBundle(taxonomy, target_text, ext_dict, ext_text, reports, filers, silver,
                      gold_reports, gold_items, gold_occ, esef_reports, esef_occ, ifrs, dep,
                      splits, meta)
