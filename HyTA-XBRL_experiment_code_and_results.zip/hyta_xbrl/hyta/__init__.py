"""HyTA-XBRL: zero shot alignment of XBRL extension elements.

Modules follow section 3 of the manuscript one to one.

    hyta.modules.migmine    equations (2) (3) (4)
    hyta.modules.lorentz    equations (5) (6) (7) (8)
    hyta.modules.hyperank   equations (9) (10) (11)
    hyta.modules.calcjoint  equations (12) (13) (14) (15)
    hyta.modules.confsel    equations (16) (17)
"""
__version__ = "1.0.0"
