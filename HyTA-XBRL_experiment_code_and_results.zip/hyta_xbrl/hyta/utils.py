"""Shared helpers: seeding, timing, caching, table export."""
from __future__ import annotations
import json
import os
import time
import hashlib
import contextlib
from typing import Any, Dict, Iterable

import numpy as np
import pandas as pd

try:
    import torch
    _HAS_TORCH = True
except Exception:                                     # pragma: no cover
    _HAS_TORCH = False


def set_seed(seed: int) -> np.random.Generator:
    np.random.seed(seed % (2 ** 32 - 1))
    if _HAS_TORCH:
        torch.manual_seed(seed)
    return np.random.default_rng(seed)


@contextlib.contextmanager
def timer(name: str, sink: Dict[str, float] | None = None):
    t0 = time.perf_counter()
    yield
    dt = time.perf_counter() - t0
    if sink is not None:
        sink[name] = dt
    print(f"    [{name}] {dt:.2f}s", flush=True)


def cache_key(*parts: Any) -> str:
    return hashlib.md5("|".join(str(p) for p in parts).encode()).hexdigest()[:16]


def save_npz(path: str, **arrays) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    np.savez_compressed(path, **arrays)


def load_npz(path: str):
    return np.load(path, allow_pickle=True) if os.path.exists(path) else None


def write_json(path: str, obj: Any) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as fh:
        json.dump(obj, fh, indent=2, default=_default)


def _default(o):
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, (np.ndarray,)):
        return o.tolist()
    raise TypeError(str(type(o)))


def write_table(path: str, frame: pd.DataFrame) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    frame.to_csv(path, index=False)
    print(f"    wrote {os.path.relpath(path)}  ({len(frame)} rows)")


def banner(text: str) -> None:
    print("\n" + "=" * 78)
    print(text)
    print("=" * 78, flush=True)
