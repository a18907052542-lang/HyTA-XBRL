"""The four groups of metrics of Table 4."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, Optional, Sequence

import numpy as np


def hit_at_k(gold_rank: np.ndarray, k: int) -> float:
    return float(np.mean((gold_rank >= 1) & (gold_rank <= k)))


def mean_reciprocal_rank(gold_rank: np.ndarray) -> float:
    rr = np.where(gold_rank >= 1, 1.0 / np.maximum(gold_rank, 1), 0.0)
    return float(rr.mean())


def graded_score(top1_tree_distance: np.ndarray, gamma: float, cutoff: int) -> float:
    """Mean of equation (10) evaluated at the predicted top one candidate."""
    rel = np.power(gamma, top1_tree_distance.astype(float))
    rel = np.where(top1_tree_distance <= cutoff, rel, 0.0)
    return float(rel.mean())


def calculation_consistency_rate(report_pass: np.ndarray) -> float:
    return float(report_pass.mean())


def rate(count: int, denominator: int) -> float:
    return float(count) / float(max(denominator, 1))


@dataclass
class RetrievalMetrics:
    hit1: float
    hit5: float
    mrr: float
    hgs: float

    def as_dict(self) -> Dict[str, float]:
        return {k: round(v, 4) for k, v in asdict(self).items()}


@dataclass
class AccountingMetrics:
    ccr: float
    dup: float
    sgn: float
    attr: float

    def as_dict(self) -> Dict[str, float]:
        return {k: round(v, 4) for k, v in asdict(self).items()}


@dataclass
class ReliabilityMetrics:
    coverage: float
    selective_accuracy: float
    empirical_error: float

    def as_dict(self) -> Dict[str, float]:
        return {k: round(v, 4) for k, v in asdict(self).items()}


def retrieval(gold_rank: np.ndarray, top1_distance: np.ndarray,
              gamma: float, cutoff: int) -> RetrievalMetrics:
    return RetrievalMetrics(hit_at_k(gold_rank, 1), hit_at_k(gold_rank, 5),
                            mean_reciprocal_rank(gold_rank),
                            graded_score(top1_distance, gamma, cutoff))


def paired_bootstrap(correct_a: np.ndarray, correct_b: np.ndarray,
                     resamples: int, rng: np.random.Generator):
    """Paired bootstrap of the difference in a mean, as in section 4.2."""
    n = len(correct_a)
    diffs = np.empty(resamples)
    for b in range(resamples):
        idx = rng.integers(0, n, n)
        diffs[b] = correct_a[idx].mean() - correct_b[idx].mean()
    return float(diffs.mean()), (float(np.percentile(diffs, 2.5)),
                                 float(np.percentile(diffs, 97.5)))
