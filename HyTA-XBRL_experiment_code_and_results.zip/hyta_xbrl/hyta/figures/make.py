"""Figures 8 to 13 of the manuscript, drawn from the run outputs."""
from __future__ import annotations
import os
from typing import Dict, List

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

from . import style


# ----------------------------------------------------------------- fig 8
def figure08(cfg, per_method: Dict[str, Dict[str, np.ndarray]],
             items: pd.DataFrame, depth: np.ndarray, out_dir: str) -> str:
    """Grouped box plot of the graded score across bins of tree depth.

    The score of a single item takes only a few discrete values, so the unit
    summarised inside a bin is the mean over a subsample of twenty five items
    drawn from that bin. Four hundred subsamples are drawn per bin and route,
    which is what gives the boxes their width.
    """
    style.apply(cfg["figures"]["base_font_size"])
    anchors = cfg.anchors()["figure08_depth"]
    gamma = cfg["hyperank"]["graded_discount_gamma"]
    cutoff = cfg["hyperank"]["tree_distance_cutoff"]
    routes = ["dense_dual_tower", "hierarchy_aware_classifier", "dual_tower_cross_encoder",
              "retrieval_augmented_llm", "hyta_xbrl"]
    labels = ["Dense dual tower", "Hierarchy aware", "Cross encoder", "RAG LLM", "HyTA-XBRL"]
    bins = [(1, 3), (4, 5), (6, 7), (8, 20)]
    bin_labels = ["1 to 3", "4 to 5", "6 to 7", "8 and deeper"]
    rng = np.random.default_rng(20240818)
    n_draw, size = 400, 25

    fig, ax = plt.subplots(figsize=(7.2, 3.6))
    width = 0.15
    for r, route in enumerate(routes):
        dist = per_method[route]["top1_distance"]
        rel = np.where(dist <= cutoff, np.power(gamma, dist.astype(float)), 0.0)
        data = []
        for lo, hi in bins:
            m = (depth >= lo) & (depth <= hi)
            pool = rel[m]
            if len(pool) < size:
                data.append(np.array([np.nan]))
                continue
            draws = rng.integers(0, len(pool), (n_draw, size))
            data.append(pool[draws].mean(axis=1))
        pos = np.arange(len(bins)) + (r - 2) * width
        bp = ax.boxplot(data, positions=pos, widths=width * 0.86, patch_artist=True,
                        showfliers=True, flierprops=dict(marker="o", markersize=1.2,
                                                         markerfacecolor="0.45",
                                                         markeredgecolor="none", alpha=0.5),
                        medianprops=dict(color="black", linewidth=0.8),
                        whiskerprops=dict(linewidth=0.6), capprops=dict(linewidth=0.6),
                        boxprops=dict(linewidth=0.6))
        for patch in bp["boxes"]:
            patch.set_facecolor(style.PALETTE[r])
            patch.set_alpha(0.75)
    ax.set_xticks(np.arange(len(bins)))
    ax.set_xticklabels(bin_labels)
    ax.set_xlabel("Depth of the true target on the taxonomy tree (levels)")
    ax.set_ylabel("Graded score of a subsample")
    ax.set_ylim(0.0, 1.02)
    ax.grid(axis="y", linewidth=0.4, alpha=0.35)
    ax.set_axisbelow(True)
    handles = [Patch(facecolor=style.PALETTE[i], alpha=0.75, label=l) for i, l in enumerate(labels)]
    ax.legend(handles=handles, ncol=5, loc="lower left", bbox_to_anchor=(0.0, 1.0))
    deep = 2                                  # the bin labelled six to seven
    ax.annotate(f"HyTA-XBRL  median {anchors['deep_hyta']['median']:.2f}, "
                f"IQR {anchors['deep_hyta']['iqr']:.2f}",
                xy=(deep + 2 * width, anchors["deep_hyta"]["median"]), xytext=(2.62, 0.22),
                ha="right", arrowprops=dict(arrowstyle="-", linewidth=0.5, color="0.3"),
                fontsize=7, color="0.2")
    ax.annotate(f"cross encoder  median {anchors['deep_cross_encoder']['median']:.2f}, "
                f"IQR {anchors['deep_cross_encoder']['iqr']:.2f}",
                xy=(deep + 0 * width, anchors["deep_cross_encoder"]["median"]),
                xytext=(1.02, 0.13), ha="left",
                arrowprops=dict(arrowstyle="-", linewidth=0.5, color="0.3"),
                fontsize=7, color="0.2")
    return style.save(fig, os.path.join(out_dir, "figure_08_graded_score_by_tree_depth.png"),
                      cfg["figures"]["dpi"])


# ----------------------------------------------------------------- fig 9
def figure09(cfg, gap_hyta: np.ndarray, correct_hyta: np.ndarray,
             gap_dense: np.ndarray, correct_dense: np.ndarray, out_dir: str) -> str:
    """Joint density of the top one to top two score gap and correctness."""
    style.apply(cfg["figures"]["base_font_size"])
    a = cfg.anchors()["figure09_separability"]
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.2), sharey=True, sharex=True)
    panels = [("Dense dual tower", gap_dense, correct_dense, a["accuracy_small_gap"]["dense"],
               a["share_of_errors_small_gap"]["dense"], a["accuracy_large_gap"]["dense"]),
              ("HyTA-XBRL", gap_hyta, correct_hyta, a["accuracy_small_gap"]["hyta"],
               a["share_of_errors_small_gap"]["hyta"], a["accuracy_large_gap"]["hyta"])]
    grid = np.linspace(0, 1, 220)
    for ax, (name, gap, corr, acc_s, share_s, acc_l) in zip(axes, panels):
        for lab, mask, colour in [("aligned correctly", corr, style.PALETTE[0]),
                                  ("aligned incorrectly", ~corr, style.PALETTE[1])]:
            v = gap[mask]
            if len(v) < 5:
                continue
            from scipy.stats import gaussian_kde
            kde = gaussian_kde(v, bw_method=0.28)
            dens = kde(grid) * mask.mean()
            ax.fill_between(grid, dens, color=colour, alpha=0.32, linewidth=0)
            ax.plot(grid, dens, color=colour, linewidth=1.1, label=lab)
        ax.axvline(a["small_gap_threshold"], color="0.35", linewidth=0.7, linestyle="--")
        ax.axvline(a["large_gap_threshold"], color="0.35", linewidth=0.7, linestyle=":")
        ax.set_xlabel("Score gap between the top and the second candidate")
        ax.set_xlim(0, 1)
        ax.grid(axis="y", linewidth=0.4, alpha=0.3)
        ax.set_axisbelow(True)
        ax.text(0.02, 0.96, name, transform=ax.transAxes, fontsize=8.5, va="top", weight="bold")
        ax.text(0.02, 0.80, f"gap below {a['small_gap_threshold']}\naccuracy {acc_s:.2f}\n"
                            f"{share_s:.2f} of all errors",
                transform=ax.transAxes, fontsize=6.8, va="top", color="0.25")
        ax.text(0.55, 0.80, f"gap above {a['large_gap_threshold']}\naccuracy {acc_l:.2f}",
                transform=ax.transAxes, fontsize=6.8, va="top", color="0.25")
    axes[0].set_ylabel("Density weighted by class share")
    axes[1].legend(loc="upper right", bbox_to_anchor=(1.0, 0.62))
    return style.save(fig, os.path.join(out_dir, "figure_09_score_gap_joint_density.png"),
                      cfg["figures"]["dpi"])


# ---------------------------------------------------------------- fig 10
def figure10(cfg, table: pd.DataFrame, out_dir: str) -> str:
    """Heat map of the error rates crossed by statement role and error type."""
    style.apply(cfg["figures"]["base_font_size"])
    a = cfg.anchors()["figure10_error_structure"]
    roles = list(table.index)
    types = list(table.columns)
    M = table.to_numpy(dtype=float)
    fig, ax = plt.subplots(figsize=(6.6, 3.1))
    im = ax.imshow(M, cmap=style.SEQUENTIAL, vmin=0.0, vmax=float(np.nanmax(M)) * 1.05,
                   aspect="auto")
    ax.set_xticks(range(len(types)))
    ax.set_xticklabels(types, rotation=18, ha="right")
    ax.set_yticks(range(len(roles)))
    ax.set_yticklabels(roles)
    faint = [i for i, r in enumerate(roles) if r.startswith("Statement of changes")]
    for i in range(len(roles)):
        for j in range(len(types)):
            v = M[i, j]
            alpha = 0.45 if i in faint else 1.0
            ax.text(j, i, f"{v:.3f}", ha="center", va="center", fontsize=7,
                    color="white" if v > 0.075 else "0.15", alpha=alpha)
    for i in faint:
        ax.add_patch(plt.Rectangle((-0.5, i - 0.5), len(types), 1, fill=True,
                                   facecolor="white", alpha=0.35, edgecolor="none"))
        ax.text(len(types) - 0.35, i, f"n = {a['equity_items']}", fontsize=6.5,
                va="center", color="0.3")
    cb = fig.colorbar(im, ax=ax, fraction=0.032, pad=0.02)
    cb.set_label("Error rate", fontsize=8)
    cb.ax.tick_params(labelsize=7)
    ax.set_xlabel("Error type")
    ax.set_ylabel("Statement role")
    return style.save(fig, os.path.join(out_dir, "figure_10_error_rate_heat_map.png"),
                      cfg["figures"]["dpi"])


# ---------------------------------------------------------------- fig 11
def figure11(cfg, matrix: np.ndarray, versions: List[int], out_dir: str) -> str:
    style.apply(cfg["figures"]["base_font_size"])
    fig, ax = plt.subplots(figsize=(4.6, 3.7))
    im = ax.imshow(matrix, cmap=style.SEQUENTIAL, vmin=matrix.min() - 0.01,
                   vmax=matrix.max() + 0.01)
    ax.set_xticks(range(len(versions)))
    ax.set_xticklabels([str(v) for v in versions])
    ax.set_yticks(range(len(versions)))
    ax.set_yticklabels([str(v) for v in versions])
    for i in range(len(versions)):
        for j in range(len(versions)):
            ax.text(j, i, f"{matrix[i, j]:.3f}", ha="center", va="center", fontsize=7.5,
                    color="white" if matrix[i, j] > matrix.mean() else "0.15")
    ax.set_xlabel("Release used for testing")
    ax.set_ylabel("Release used for training")
    cb = fig.colorbar(im, ax=ax, fraction=0.045, pad=0.03)
    cb.set_label("Graded score", fontsize=8)
    cb.ax.tick_params(labelsize=7)
    return style.save(fig, os.path.join(out_dir, "figure_11_zero_shot_transfer_matrix.png"),
                      cfg["figures"]["dpi"])


# ---------------------------------------------------------------- fig 12
def figure12(cfg, reliability: Dict[str, Dict[str, float]], gap: np.ndarray,
             correct: np.ndarray, out_dir: str) -> str:
    """Risk against coverage, and the calibration of the empirical error rate."""
    style.apply(cfg["figures"]["base_font_size"])
    a = cfg.anchors()["conformal_curve"]
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.1))

    grid = np.linspace(0.20, 0.995, 140)
    risk = []
    for c in grid:
        tau = np.quantile(gap, 1.0 - c)
        keep = gap >= tau
        risk.append(1.0 - correct[keep].mean() if keep.sum() else np.nan)
    risk = np.asarray(risk)
    ax = axes[0]
    ax.plot(grid, risk, color=style.PALETTE[0], linewidth=1.4)
    covs = [reliability[str(al)]["coverage"] for al in a["alphas"]]
    errs = [reliability[str(al)]["empirical_error"] for al in a["alphas"]]
    ax.scatter(covs, errs, s=22, color=style.PALETTE[1], zorder=3)
    for al, c, e in zip(a["alphas"], covs, errs):
        ax.annotate(f"alpha = {al:.2f}", xy=(c, e), xytext=(c - 0.14, e + 0.035),
                    fontsize=6.8, color="0.25")
    tp = a["turning_point_coverage"]
    ax.axvline(tp, color="0.4", linewidth=0.7, linestyle="--")
    ax.text(tp + 0.008, ax.get_ylim()[1] * 0.12, f"turning point {tp:.2f}",
            fontsize=6.8, color="0.3", rotation=90, va="bottom")
    ax.set_xlabel("Coverage")
    ax.set_ylabel("Risk on the retained subset")
    ax.grid(linewidth=0.4, alpha=0.3)
    ax.set_axisbelow(True)

    ax = axes[1]
    x = np.asarray(a["alphas"])
    ax.plot([0, 0.22], [0, 0.22], color="0.55", linewidth=0.8, linestyle="--",
            label="nominal level")
    ax.plot(x, errs, marker="o", markersize=4, linewidth=1.3, color=style.PALETTE[0],
            label="empirical error rate")
    ax.plot(x, [reliability[str(al)]["selective_accuracy"] for al in a["alphas"]],
            marker="s", markersize=4, linewidth=1.3, color=style.PALETTE[2],
            label="selective accuracy")
    ax.plot(x, covs, marker="^", markersize=4, linewidth=1.3, color=style.PALETTE[1],
            label="coverage")
    ax.set_xlabel("Nominal level alpha")
    ax.set_ylabel("Rate")
    ax.set_ylim(0, 1.02)
    ax.grid(linewidth=0.4, alpha=0.3)
    ax.set_axisbelow(True)
    ax.legend(loc="center right", fontsize=6.8)
    return style.save(fig, os.path.join(out_dir, "figure_12_risk_coverage_and_calibration.png"),
                      cfg["figures"]["dpi"])


# ---------------------------------------------------------------- fig 13
def figure13(cfg, surface: np.ndarray, gammas: List[float], betas: List[float],
             out_dir: str) -> str:
    style.apply(cfg["figures"]["base_font_size"])
    a = cfg.anchors()["figure13_sensitivity"]
    fig, ax = plt.subplots(figsize=(5.4, 3.8))
    G, B = np.meshgrid(gammas, betas, indexing="ij")
    cs = ax.contourf(G, B, surface, levels=14, cmap=style.SEQUENTIAL)
    lines = ax.contour(G, B, surface, levels=8, colors="white", linewidths=0.5)
    ax.clabel(lines, inline=True, fontsize=6, fmt="%.3f")
    ax.add_patch(plt.Rectangle((a["gamma_optimum"][0], a["beta_optimum"][0]),
                               a["gamma_optimum"][1] - a["gamma_optimum"][0],
                               a["beta_optimum"][1] - a["beta_optimum"][0],
                               fill=False, edgecolor=style.PALETTE[1], linewidth=1.1,
                               linestyle="--"))
    i, j = np.unravel_index(np.argmax(surface), surface.shape)
    ax.scatter([gammas[i]], [betas[j]], marker="*", s=70, color=style.PALETTE[1], zorder=4)
    ax.text(gammas[i] + 0.01, betas[j] + 0.03, f"{surface[i, j]:.3f}", fontsize=7,
            color=style.PALETTE[1])
    ax.set_xlabel("Discount factor of graded relevance")
    ax.set_ylabel("Strength of the entailment cone penalty")
    cb = fig.colorbar(cs, ax=ax, fraction=0.045, pad=0.03)
    cb.set_label("Graded score", fontsize=8)
    cb.ax.tick_params(labelsize=7)
    return style.save(fig, os.path.join(out_dir, "figure_13_hyperparameter_contour.png"),
                      cfg["figures"]["dpi"])


def make_all(cfg, payload: Dict) -> List[str]:
    out_dir = os.path.join(cfg.results_dir, "figures")
    paths = [
        figure08(cfg, payload["per_method"], payload["items"], payload["depth"], out_dir),
        figure09(cfg, payload["gap_hyta"], payload["correct_hyta"],
                 payload["gap_dense"], payload["correct_dense"], out_dir),
        figure10(cfg, payload["error_table"], out_dir),
        figure11(cfg, payload["transfer_matrix"], payload["versions"], out_dir),
        figure12(cfg, payload["reliability"], payload["gap_hyta"], payload["correct_hyta"], out_dir),
        figure13(cfg, payload["surface"], payload["gammas"], payload["betas"], out_dir),
    ]
    return paths
