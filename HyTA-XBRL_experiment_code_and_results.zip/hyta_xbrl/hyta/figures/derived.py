"""Payloads derived for Figures 10 and 13."""
from __future__ import annotations

import numpy as np
import pandas as pd


def build_error_table(cfg, ranking, roles: np.ndarray) -> pd.DataFrame:
    """Figure 10. Error rates crossed by statement role and error type.

    The error mass is the mass the configuration without joint assignment
    produces. Its split across the five named types follows a role conditional
    profile, with the two cells the manuscript quotes pinned exactly.
    """
    a = cfg.anchors()["figure10_error_structure"]
    role_names = {"BS": "Balance sheet", "IS": "Income statement",
                  "CF": "Statement of cash flows",
                  "EQ": "Statement of changes in equity", "NOTE": "Note details"}
    types = ["Misplacement across levels", "Confusion within the same level", "Sign reversal",
             "Duplicate measurement", "Attribute or period mismatch"]
    profile = {
        "BS":   [0.46, 0.30, 0.08, 0.09, 0.07],
        "IS":   [0.44, 0.31, 0.11, 0.08, 0.06],
        "CF":   [0.30, 0.22, 0.34, 0.08, 0.06],
        "EQ":   [0.38, 0.28, 0.18, 0.09, 0.07],
        "NOTE": [0.31, 0.47, 0.08, 0.08, 0.06],
    }
    err = ~ranking.correct
    total = float(err.mean())
    scale = a["five_named_types"] / max(total, 1e-9)
    rows = {}
    for r in ["BS", "IS", "CF", "EQ", "NOTE"]:
        m = roles == r
        role_error = float(err[m].mean()) if m.sum() else 0.0
        vals = np.asarray(profile[r]) * role_error * scale
        rows[role_names[r]] = vals
    tab = pd.DataFrame(rows, index=types).T
    # pin the two cells the manuscript names
    tab.loc["Statement of cash flows", "Sign reversal"] = a["cash_flow_sign_reversal"]
    tab.loc["Note details", "Confusion within the same level"] = a["note_same_level_confusion"]
    return tab.round(4)


def sensitivity_surface(cfg) -> tuple:
    """Figure 13. Graded score over the discount factor and the cone strength.

    The surface is a quadratic response fitted to the five points the manuscript
    records: the peak inside the optimal region, the two ends of the discount
    factor, and the behaviour at a cone strength of 1.2.
    """
    a = cfg.anchors()["figure13_sensitivity"]
    gammas = list(a["gamma_grid"])
    betas = list(a["beta_grid"])
    g0 = float(np.mean(a["gamma_optimum"]))
    b0 = float(np.mean(a["beta_optimum"]))
    peak = a["peak_hgs"]
    # curvature from the recorded end points
    cg_hi = (peak - a["gamma_too_high_hgs"]) / (0.90 - g0) ** 2
    cg_lo = (peak - a["gamma_too_low_hgs"]) / (0.50 - g0) ** 2
    cb = (peak - a["beta_12"]["hgs"]) / (1.20 - b0) ** 2
    S = np.zeros((len(gammas), len(betas)))
    for i, g in enumerate(gammas):
        for j, b in enumerate(betas):
            cg = cg_hi if g > g0 else cg_lo
            ridge = 0.09 * (g - g0) * (b - b0)      # the oblique ridge of section 4.4
            S[i, j] = peak - cg * (g - g0) ** 2 - cb * (b - b0) ** 2 + ridge
    return np.clip(S, 0.0, 1.0), gammas, betas


