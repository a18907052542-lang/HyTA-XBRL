"""Shared plotting style for Figures 8 to 13.

White background, English labels only, no title inside the figure, resolution
not below 800 dots per inch.
"""
from __future__ import annotations
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import rcParams

PALETTE = ["#1F4E79", "#C0504D", "#4E8542", "#8064A2", "#E36C0A", "#31859B", "#7F7F7F"]
SEQUENTIAL = "YlGnBu"
DIVERGING = "RdYlBu_r"


def apply(base_font: int = 9) -> None:
    rcParams.update({
        "figure.facecolor": "white",
        "savefig.facecolor": "white",
        "axes.facecolor": "white",
        "font.family": "DejaVu Sans",
        "font.size": base_font,
        "axes.labelsize": base_font + 1,
        "axes.titlesize": base_font + 1,
        "xtick.labelsize": base_font - 1,
        "ytick.labelsize": base_font - 1,
        "legend.fontsize": base_font - 1,
        "axes.linewidth": 0.7,
        "xtick.major.width": 0.7,
        "ytick.major.width": 0.7,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "legend.frameon": False,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.03,
    })


def save(fig, path: str, dpi: int) -> str:
    import os
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fig.savefig(path, dpi=dpi)
    plt.close(fig)
    print(f"    wrote {os.path.relpath(path)}")
    return path
