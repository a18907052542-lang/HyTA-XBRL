"""Unit tests for every equation of section 3.

    python -m pytest tests -q          or        python tests/test_formulas.py
"""
from __future__ import annotations
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import torch

from hyta.modules import calcjoint, confsel, hyperank, migmine
from hyta.modules import lorentz as L


def test_equation_5_distance_is_a_metric():
    x = L.exp_map_origin(torch.randn(6, 5) * 0.4)
    assert torch.allclose(L.minkowski_dot(x, x), -torch.ones(6), atol=1e-4)
    d = L.lorentz_distance(x[0], x[0])
    assert float(d) < 1e-3
    a, b, c = x[0], x[1], x[2]
    lhs = float(L.lorentz_distance(a, c))
    rhs = float(L.lorentz_distance(a, b)) + float(L.lorentz_distance(b, c))
    assert lhs <= rhs + 1e-4


def test_equations_6_and_7_maps_are_inverse():
    h = torch.randn(8, 5) * 0.5
    x = L.exp_map_origin(h)
    assert torch.allclose(L.log_map_origin(x), h, atol=1e-4)
    prop = hyperank.HyperbolicGraphPropagation(2)
    parent = torch.tensor([-1, 0, 0, 1, 1, 2, 2, 3])
    y = prop(x, parent)
    assert torch.allclose(L.minkowski_dot(y, y), -torch.ones(8), atol=1e-3)


def test_equation_8_cone_half_angle_shrinks_with_depth():
    near = L.exp_map_origin(torch.full((1, 4), 0.20))
    far = L.exp_map_origin(torch.full((1, 4), 2.00))
    psi_near = float(L.cone_half_angle(near, 0.1))
    psi_far = float(L.cone_half_angle(far, 0.1))
    assert psi_near > psi_far > 0.0


def test_equation_2_numeric_continuity():
    v_y = np.array([100.0, 100.0, 0.0])
    v_y1 = np.array([101.0, 130.0, 0.0])
    gap = migmine.numeric_continuity(v_y, v_y1, epsilon=1e-6)
    assert np.isclose(gap[0], 0.01) and gap[1] > 0.02
    assert np.isfinite(gap[2])


def test_equation_3_weights_must_sum_to_one():
    phi = np.tile(np.array([[1.0, 1.0, 1.0, 1.0]]), (3, 1))
    assert np.allclose(migmine.combine_confidence(phi, [0.35, 0.25, 0.25, 0.15]), 1.0)
    try:
        migmine.combine_confidence(phi, [0.5, 0.5, 0.5, 0.5])
    except ValueError:
        return
    raise AssertionError("weights that do not sum to one must be rejected")


def test_equation_4_selects_the_small_loss_part():
    conf = np.full(10, 0.9)
    loss = np.arange(10, dtype=float)
    full = migmine.mining_loss(conf, loss, rho=1.0, lam=1.0)
    part = migmine.mining_loss(conf, loss, rho=1.0, lam=0.7)
    assert part < full


def test_equation_9_cone_penalty_only_bites_outside_the_cone():
    model = hyperank.HypeRank(4, 3, 1, K=0.1, beta=0.6)
    src = L.exp_map_origin(torch.randn(2, 3) * 0.4)
    tgt = L.exp_map_origin(torch.randn(2, 3) * 0.4)
    with_cone = model.score(src, tgt)
    model.use_cone = False
    without = model.score(src, tgt)
    assert torch.all(with_cone <= without + 1e-6)


def test_equation_10_graded_relevance():
    d = torch.tensor([0, 1, 2, 6, 7])
    rel = hyperank.graded_relevance(d, gamma=0.7, cutoff=6)
    assert np.isclose(float(rel[0]), 1.0)
    assert np.isclose(float(rel[2]), 0.49, atol=1e-6)
    assert float(rel[4]) == 0.0
    assert torch.all(rel[:4].diff() < 0)


def test_equation_11_loss_is_zero_when_the_order_is_wide_enough():
    scores = torch.tensor([[5.0, 0.0]])
    rel = torch.tensor([[1.0, 0.0]])
    assert float(hyperank.listwise_margin_loss(scores, rel, 0.3)) == 0.0
    bad = torch.tensor([[0.0, 5.0]])
    assert float(hyperank.listwise_margin_loss(bad, rel, 0.3)) > 0.0


def test_equations_12_to_14_assignment_respects_the_constraints():
    rng = np.random.default_rng(0)
    n, m = 4, 3
    values = np.array([10.0, 20.0, 30.0, 40.0])
    weights = np.ones(n)
    cand = np.tile(np.arange(m), (n, 1))
    scores = rng.random((n, m))
    group = np.zeros(n, dtype=int)
    problem = calcjoint.ReportProblem(
        element_ids=[f"e{i}" for i in range(n)], candidate_ids=cand, scores=scores,
        values=values, filer_weight=weights, sibling_group=group,
        parent_value={0: float(values.sum())}, target_weight=np.ones((n, m)),
        attribute_ok=np.ones((n, m), dtype=bool), eta=-1.0)
    sol = calcjoint.solve_report(problem, kappa=0.005, time_limit=5.0,
                                strong_coupling_block_size=10 ** 6)
    assert sol.status == "optimal"
    chosen = [int(cand[i, j]) for i, j in enumerate(sol.chosen) if j >= 0]
    assert len(chosen) == len(set(chosen)) or len(chosen) <= m


def test_equation_14_soft_assignment_rows_sum_to_one():
    z = calcjoint.soft_assignment(np.random.rand(5, 4), mu=0.05,
                                  multipliers=np.zeros(5),
                                  violation_jacobian=np.zeros((5, 4)))
    assert np.allclose(z.sum(axis=1), 1.0)


def test_equation_15_total_loss_is_additive():
    assert np.isclose(calcjoint.total_loss(1.0, 2.0, np.array([0.5, 0.5]), 0.4), 3.4)


def test_equation_16_threshold_is_the_conformal_quantile():
    a = np.arange(100, dtype=float)
    tau = confsel.conformal_threshold(a, alpha=0.10)
    assert 88.0 <= tau <= 92.0


def test_equation_17_selection_raises_accuracy():
    rng = np.random.default_rng(3)
    n = 4000
    correct = rng.random(n) < 0.68
    gap = rng.random(n) * 0.5 + correct * 0.4
    score = confsel.nonconformity(gap, np.zeros(n), gap_weight=0.6, top_weight=0.4)
    tau = np.quantile(score, 0.664)
    res = confsel.apply(score, correct, tau)
    assert res.selective_accuracy > correct.mean()
    assert 0.60 < res.coverage < 0.72


def main() -> None:
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"  ok  {fn.__name__}")
    print(f"\n{len(fns)} tests passed")


if __name__ == "__main__":
    main()
