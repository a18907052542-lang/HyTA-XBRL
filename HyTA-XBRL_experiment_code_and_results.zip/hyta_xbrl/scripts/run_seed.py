#!/usr/bin/env python3
"""Run the pipeline for one seed and persist its metrics.

Each seed runs in its own process so that the memory of one seed is released
before the next one starts.

    python scripts/run_seed.py --seed 11
"""
from __future__ import annotations
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import pandas as pd

from hyta import pipeline
from hyta.config import load_config
from hyta.data import load_bundle
from hyta.utils import banner, write_json


def load(cfg):
    cache = os.path.join(cfg.cache_dir, "gold_occ.pkl")
    encoded = os.path.exists(os.path.join(cfg.cache_dir, "encoding_target.npy"))
    bundle = load_bundle(cfg, with_occurrences=not os.path.exists(cache), light=encoded)
    if os.path.exists(cache):
        bundle.gold_occurrences = pd.read_pickle(cache)
    else:
        bundle.gold_occurrences.to_pickle(cache)
    return bundle


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--seed", type=int, required=True)
    ap.add_argument("--primary", action="store_true",
                    help="also persist the arrays that the figures are drawn from")
    args = ap.parse_args()
    cfg = load_config(args.config)
    banner(f"seed {args.seed}")
    bundle = load(cfg)
    out = pipeline.run(cfg, bundle, seed=args.seed)
    d = os.path.join(cfg.cache_dir, "seeds")
    os.makedirs(d, exist_ok=True)
    write_json(os.path.join(d, f"seed_{args.seed}.json"),
               dict(seed=args.seed, retrieval=out.retrieval, reliability=out.reliability,
                    accounting=out.accounting,
                    calcjoint={k: v for k, v in out.computed["calcjoint"].items()},
                    migmine_counts=out.computed["migmine_counts"],
                    candidate_recall_at_50=out.computed["candidate_recall_at_50"],
                    train_loss=out.computed["train_loss"], timings=out.timings,
                    data=bundle.meta))
    if args.primary:
        np.savez_compressed(os.path.join(d, "primary_arrays.npz"), **out.arrays)
        out.computed["calcjoint_per_report"].to_csv(
            os.path.join(cfg.results_dir, "tables", "calcjoint_per_report.csv"), index=False)
    print(f"    seed {args.seed} done")


if __name__ == "__main__":
    main()
