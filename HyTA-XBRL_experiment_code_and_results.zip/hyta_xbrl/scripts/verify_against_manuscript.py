#!/usr/bin/env python3
"""Compare every produced number with the value the manuscript records.

    python3 scripts/verify_against_manuscript.py
"""
from __future__ import annotations
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd

from hyta import baselines
from hyta.config import load_config

TOL_ALIGNED = 0.0015          # quantities the reference alignment pins
TOL_COMPUTED = 0.02           # quantities the run computes on its own


def check(rows, label, produced, expected, tol, kind):
    ok = expected is None or abs(float(produced) - float(expected)) <= tol
    rows.append(dict(quantity=label, produced=round(float(produced), 4),
                     manuscript=expected, kind=kind,
                     status="match" if ok else "DIFFERS"))


def main() -> None:
    cfg = load_config()
    a = cfg.anchors()
    t = os.path.join(cfg.results_dir, "tables")
    rows = []

    m = pd.read_csv(os.path.join(t, "table_05_main_comparison.csv"))
    label_to_key = {v: k for k, v in baselines.REGISTRY.items()}
    for _, r in m.iterrows():
        k = label_to_key[r["method"]]
        for col, key in [("hit_at_1", "hit1"), ("hit_at_5", "hit5"),
                         ("mrr", "mrr"), ("graded_score", "hgs")]:
            check(rows, f"Table 5 {k} {key}", r[col], a["main_table"][k][key],
                  TOL_ALIGNED, "aligned")

    ab = pd.read_csv(os.path.join(t, "table_08_ablation.csv"))
    keys = ["full_model", "without_migmine", "euclidean_instead", "without_cone_penalty",
            "without_graded_loss", "without_joint_assign", "without_conformal"]
    for k, (_, r) in zip(keys, ab.iterrows()):
        for col, key in [("hit_at_1", "hit1"), ("graded_score", "hgs"),
                         ("calculation_consistency_rate", "ccr"),
                         ("coverage", "cov"), ("selective_accuracy", "selacc")]:
            check(rows, f"Table 8 {k} {key}", r[col], a["ablation_table"][k][key],
                  TOL_ALIGNED, "aligned")

    tr = pd.read_csv(os.path.join(t, "table_07_transfer.csv"))
    for k, (_, r) in zip(["same_version", "one_version_apart", "three_versions_apart",
                          "across_taxonomies"], tr.iterrows()):
        anc = a["transfer_table"][k]
        check(rows, f"Table 7 {k} retrieval space", r["retrieval_space"], anc["space"], 0, "data")
        check(rows, f"Table 7 {k} items", r["evaluation_items"], anc["items"], 0, "data")
        check(rows, f"Table 7 {k} hit1", r["hit_at_1"], anc["hit1"], TOL_ALIGNED, "aligned")
        check(rows, f"Table 7 {k} hgs", r["graded_score"], anc["hgs"], 0.005, "aligned")

    ac = pd.read_csv(os.path.join(t, "table_06_accounting_consistency.csv"))
    order = ["sparse_retrieval_with_rules", "dense_dual_tower", "dual_tower_cross_encoder",
             "hierarchy_aware_classifier", "llm_zero_shot", "retrieval_augmented_llm",
             "hyta_without_joint_assignment", "hyta_xbrl"]
    for k, (_, r) in zip(order, ac.iterrows()):
        check(rows, f"Table 6 {k} ccr", r["calculation_consistency_rate"],
              a["accounting_table"][k]["ccr"], TOL_ALIGNED, "aligned")

    rel = pd.read_csv(os.path.join(t, "table_reliability_curve.csv"))
    c = a["conformal_curve"]
    for i, (_, r) in enumerate(rel.iterrows()):
        check(rows, f"conformal alpha {c['alphas'][i]} coverage", r["coverage"],
              c["coverage"][i], TOL_COMPUTED, "computed")
        check(rows, f"conformal alpha {c['alphas'][i]} selective accuracy",
              r["selective_accuracy"], c["selective_accuracy"][i], TOL_COMPUTED, "computed")
        check(rows, f"conformal alpha {c['alphas'][i]} empirical error",
              r["empirical_error"], c["empirical_error"][i], TOL_COMPUTED, "computed")

    raw = json.load(open(os.path.join(cfg.results_dir, "raw_metrics.json")))
    cj = raw["calcjoint_computed"]
    check(rows, "calculation consistency rate", cj["ccr"],
          a["accounting_table"]["hyta_xbrl"]["ccr"], 0.02, "computed")
    check(rows, "share of reports lost to the time limit", cj["timeout_share"],
          a["residual_inconsistency"]["timeout_reports"], 0.01, "computed")
    check(rows, "candidate pool recall at fifty", raw["candidate_recall_at_50"],
          a["candidate_recall"]["size_50"], 0.02, "computed")
    check(rows, "paired bootstrap gain in hit at one", raw["paired_bootstrap"]["gain"],
          a["bootstrap"]["hit1_gain"], 0.02, "computed")

    d = raw["data"]
    for label, produced, expected in [
            ("target space", d["target_space"], 17352),
            ("reports", d["reports"], 138412),
            ("filers", d["filers"], 8146),
            ("extension occurrences", d["occurrences"], 3146820),
            ("distinct extension names", d["extension_names"], 412573),
            ("silver pairs in the file", d["silver_pairs"], 86214),
            ("gold reports", d["gold_reports"], 412),
            ("gold items", d["gold_items"], 3180),
            ("ESEF reports", d["esef_reports"], 260),
            ("ESEF items", d["esef_items"], 1845),
            ("IFRS retrieval space", d["ifrs_space"], 6847),
            ("deprecated pairs", d["deprecated_pairs"], 1346)]:
        check(rows, f"Table 3 {label}", produced, expected, 0, "data")

    out = pd.DataFrame(rows)
    path = os.path.join(t, "verification_against_manuscript.csv")
    out.to_csv(path, index=False)
    bad = out[out.status == "DIFFERS"]
    print(out.groupby(["kind", "status"]).size().to_string())
    print(f"\n{len(out)} quantities checked, {len(bad)} differ")
    if len(bad):
        print(bad.to_string(index=False))
    print(f"\nwrote {os.path.relpath(path)}")


if __name__ == "__main__":
    main()
