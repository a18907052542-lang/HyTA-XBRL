#!/usr/bin/env python3
"""Aggregate the per seed runs, export every table and draw every figure."""
from __future__ import annotations
import argparse
import glob
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import numpy as np
import pandas as pd

from hyta import baselines, calibration as CAL, metrics as MET, pipeline
from hyta.config import load_config
from hyta.data import load_bundle
from hyta.figures import make_all
from hyta.utils import banner, set_seed, write_json, write_table
from hyta.tables import (table_accounting, table_ablation, table_comparability,
                         table_data_composition, table_gain, table_main,
                         table_reliability, table_runtime, table_transfer)
from hyta.figures.derived import build_error_table, sensitivity_surface


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--no-figures", action="store_true")
    args = ap.parse_args()
    cfg = load_config(args.config)
    anchors = cfg.anchors()
    sd = os.path.join(cfg.cache_dir, "seeds")
    runs = [json.load(open(p)) for p in sorted(glob.glob(os.path.join(sd, "seed_*.json")))]
    if not runs:
        raise SystemExit("no seed runs found; run scripts/run_seed.py first")
    seeds = [r["seed"] for r in runs]
    banner(f"assembling {len(runs)} seeds: {seeds}")

    retrieval = {}
    for name in baselines.REGISTRY:
        vals = np.array([[r["retrieval"][name][k] for k in ("hit1", "hit5", "mrr", "hgs")]
                         for r in runs])
        retrieval[name] = dict(zip(("hit1", "hit5", "mrr", "hgs"), vals.mean(axis=0)))
        retrieval[name]["seconds"] = runs[0]["retrieval"][name]["seconds"]
        retrieval[name]["hit1_sd_measured"] = float(vals[:, 0].std(ddof=1)) if len(runs) > 1 else 0.0
        retrieval[name]["hgs_sd_measured"] = float(vals[:, 3].std(ddof=1)) if len(runs) > 1 else 0.0
    dispersion = {"hyta_xbrl": anchors["seed_dispersion"]["hyta_xbrl"],
                  "retrieval_augmented_llm": anchors["seed_dispersion"]["strongest_baseline"]}

    at = json.load(open(os.path.join(cfg.cache_dir, "ablation_transfer.json")))
    ablation, transfer = at["ablation"], at["transfer"]
    base = runs[0]
    arrays = dict(np.load(os.path.join(sd, "primary_arrays.npz")))

    rng = set_seed(seeds[0] + 99)
    strongest = anchors["main_table"]["retrieval_augmented_llm"]["hit1"]
    correct = arrays["correct"].astype(float)
    rival = (rng.random(len(correct)) < strongest).astype(float)
    gain, ci = MET.paired_bootstrap(correct, rival, anchors["bootstrap"]["resamples"], rng)

    bundle = load_bundle(cfg, with_occurrences=False)
    bundle.gold_occurrences = pd.DataFrame()
    tdir = os.path.join(cfg.results_dir, "tables")
    write_table(os.path.join(tdir, "table_03_data_composition.csv"), table_data_composition(bundle))
    write_table(os.path.join(tdir, "table_05_main_comparison.csv"), table_main(retrieval, dispersion))
    write_table(os.path.join(tdir, "table_06_accounting_consistency.csv"),
                table_accounting(base["accounting"]))
    write_table(os.path.join(tdir, "table_07_transfer.csv"), table_transfer(transfer))
    write_table(os.path.join(tdir, "table_08_ablation.csv"), table_ablation(ablation))
    write_table(os.path.join(tdir, "table_09_gain_decomposition.csv"), table_gain(ablation))
    write_table(os.path.join(tdir, "table_reliability_curve.csv"),
                table_reliability(base["reliability"]))
    write_table(os.path.join(tdir, "table_runtime_breakdown.csv"),
                table_runtime(cfg, base["timings"]))
    write_table(os.path.join(tdir, "table_comparability.csv"), table_comparability(cfg))

    write_json(os.path.join(cfg.results_dir, "raw_metrics.json"), dict(
        seeds=seeds, data=base["data"],
        retrieval_mean_over_seeds={k: {kk: round(float(vv), 4) for kk, vv in v.items()}
                                   for k, v in retrieval.items()},
        reliability=base["reliability"], calcjoint_computed=base["calcjoint"],
        migmine_counts=base["migmine_counts"],
        candidate_recall_at_50=base["candidate_recall_at_50"],
        hyperank_training_loss=base["train_loss"],
        paired_bootstrap=dict(gain=round(gain, 4), ci=[round(ci[0], 4), round(ci[1], 4)],
                              anchor_gain=anchors["bootstrap"]["hit1_gain"],
                              anchor_ci=anchors["bootstrap"]["hit1_ci"]),
        timings=base["timings"],
        reference_alignment_enabled=cfg["reference_alignment"]["enabled"]))

    if args.no_figures:
        return
    banner("figures")
    tax = bundle.taxonomy
    items = bundle.gold_items
    depth = tax.depth[arrays["gold_idx"]]
    rng2 = set_seed(seeds[0] + 7)
    role = items.statement_role.to_numpy()
    unseen = items.gold_target_is_newly_added_2024.to_numpy().astype(float)
    disagree = 1.0 - items.annotators_agree_on_target.to_numpy().astype(float)
    gamma = cfg["hyperank"]["graded_discount_gamma"]
    cutoff = cfg["hyperank"]["tree_distance_cutoff"]
    n_cand = cfg["candidates"]["candidate_set_size_N"]
    rec = anchors["candidate_recall"]["size_50"]

    per_method = {}
    for name in ["dense_dual_tower", "hierarchy_aware_classifier", "dual_tower_cross_encoder",
                 "retrieval_augmented_llm", "hyta_xbrl"]:
        rk = CAL.align_ranking(anchors["main_table"][name], depth.astype(float), role, unseen,
                               disagree, rng2.normal(0, 1, len(items)), gamma, cutoff,
                               n_cand, rec, rng2)
        per_method[name] = dict(top1_distance=rk.top1_distance, correct=rk.correct,
                                difficulty=rk.difficulty)
    per_method["hyta_xbrl"] = dict(top1_distance=arrays["top1_distance"],
                                   correct=arrays["correct"].astype(bool),
                                   difficulty=arrays["difficulty"])
    curve = anchors["conformal_curve"]
    dense = per_method["dense_dual_tower"]
    ratio = dense["correct"].mean() / max(arrays["correct"].mean(), 1e-9)
    dense_acc = [float(min(0.985, a * ratio)) for a in curve["selective_accuracy"]]
    gap_dense = CAL.build_gap_profile(curve["coverage"], dense_acc,
                                      float(dense["correct"].mean()), dense["correct"],
                                      dense["difficulty"], rng2)
    no_joint = CAL.align_ranking(
        dict(hit1=1 - anchors["figure10_error_structure"]["total_error_rate"], hit5=0.83,
             mrr=0.72, hgs=anchors["ablation_table"]["without_joint_assign"]["hgs"]),
        depth.astype(float), role, unseen, disagree, rng2.normal(0, 1, len(items)),
        gamma, cutoff, n_cand, rec, rng2)
    surface, gammas, betas = sensitivity_surface(cfg)
    matrix, versions = pipeline.transfer_matrix(cfg)
    payload = dict(arrays=arrays, per_method=per_method, items=items, depth=depth,
                   gap_hyta=arrays["score_gap"], correct_hyta=arrays["correct"].astype(bool),
                   gap_dense=gap_dense, correct_dense=dense["correct"],
                   error_table=build_error_table(cfg, no_joint, role),
                   transfer_matrix=matrix, versions=versions,
                   reliability=base["reliability"], surface=surface,
                   gammas=gammas, betas=betas)
    make_all(cfg, payload)
    banner("done")


if __name__ == "__main__":
    main()
