#!/usr/bin/env bash
# Full experiment. Each stage runs in its own process so that memory is released.
set +e
cd "$(dirname "$0")/.."
SEEDS=${SEEDS:-"11 23 37 53 71"}
first=1
for s in $SEEDS; do
  if [ $first -eq 1 ]; then
    python3 scripts/run_seed.py --seed "$s" --primary
    first=0
  else
    python3 scripts/run_seed.py --seed "$s"
  fi
done
python3 scripts/run_ablation_transfer.py --seed $(echo $SEEDS | cut -d' ' -f1)
python3 scripts/assemble.py
