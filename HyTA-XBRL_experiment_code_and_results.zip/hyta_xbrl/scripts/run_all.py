#!/usr/bin/env python3
"""Convenience entry point: runs the staged scripts one after another.

Each stage is a separate process. Holding five seeds, the ablation and the
figures in one interpreter needs more memory than a small machine has, which is
why the work is staged rather than run inline.

    python3 scripts/run_all.py
    python3 scripts/run_all.py --seeds 11
    python3 scripts/run_all.py --no-figures
"""
from __future__ import annotations
import argparse
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)


def call(script: str, *args: str) -> None:
    cmd = [sys.executable, os.path.join(HERE, script), *args]
    print("\n$ " + " ".join(cmd), flush=True)
    result = subprocess.run(cmd, cwd=ROOT)
    if result.returncode != 0:
        raise SystemExit(f"{script} exited with status {result.returncode}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--seeds", type=int, nargs="*", default=None)
    ap.add_argument("--no-figures", action="store_true")
    args = ap.parse_args()

    import yaml
    with open(os.path.join(ROOT, args.config)) as fh:
        seeds = args.seeds or yaml.safe_load(fh)["project"]["seeds"]

    for i, s in enumerate(seeds):
        extra = ["--primary"] if i == 0 else []
        call("run_seed.py", "--config", args.config, "--seed", str(s), *extra)
    call("run_ablation_transfer.py", "--config", args.config, "--seed", str(seeds[0]))
    call("assemble.py", "--config", args.config, *(["--no-figures"] if args.no_figures else []))


if __name__ == "__main__":
    main()
