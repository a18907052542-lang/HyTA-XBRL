#!/usr/bin/env python3
"""Ablation of Table 8 and the transfer settings of Table 7, in their own process."""
from __future__ import annotations
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from hyta import pipeline
from hyta.config import load_config
from hyta.utils import banner, write_json
from run_seed import load


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/default.yaml")
    ap.add_argument("--seed", type=int, default=11)
    args = ap.parse_args()
    cfg = load_config(args.config)
    bundle = load(cfg)
    banner("ablation")
    ablation = pipeline.run_ablation(cfg, bundle, seed=args.seed)
    banner("transfer")
    transfer = pipeline.run_transfer(cfg, bundle, seed=args.seed)
    write_json(os.path.join(cfg.cache_dir, "ablation_transfer.json"),
               dict(ablation=ablation, transfer=transfer))
    print("    ablation and transfer done")


if __name__ == "__main__":
    main()
